import { cn } from '@/lib/utils'

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" fill="none" aria-hidden="true" className={cn('size-8', className)}>
      <path
        d="M16 2.5 4.5 6.8v8.4c0 6.9 4.7 11.9 11.5 14.3 6.8-2.4 11.5-7.4 11.5-14.3V6.8L16 2.5Z"
        fill="currentColor"
      />
      <path
        d="M8.5 16h4l1.8-4.2 2.8 8 2-3.8H22"
        stroke="#2cc4b0"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="23.6" cy="16" r="1.6" stroke="#2cc4b0" strokeWidth="1.6" />
    </svg>
  )
}

export function Logo({
  className,
  tone = 'dark',
  showTagline = false,
}: {
  className?: string
  tone?: 'dark' | 'light'
  showTagline?: boolean
}) {
  return (
    <span className={cn('inline-flex items-center gap-2.5', className)}>
      <LogoMark className={tone === 'dark' ? 'text-navy' : 'text-white'} />
      <span className="flex flex-col leading-none">
        <span
          className={cn(
            'text-[15px] font-semibold tracking-[0.06em]',
            tone === 'dark' ? 'text-navy' : 'text-white',
          )}
        >
          JEEVAN <span className="text-teal">RAKSHAK</span>
        </span>
        {showTagline && (
          <span
            className={cn(
              'mt-1 text-[10px] font-medium tracking-[0.12em] uppercase',
              tone === 'dark' ? 'text-muted-foreground' : 'text-sidebar-foreground/70',
            )}
          >
            Prepare. Protect. Respond.
          </span>
        )}
      </span>
    </span>
  )
}
