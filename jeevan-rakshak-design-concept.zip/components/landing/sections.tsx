import Image from 'next/image'
import Link from 'next/link'
import {
  ArrowRight,
  BellRing,
  Bot,
  HandHeart,
  LifeBuoy,
  Map,
  Phone,
  Siren,
  Radar,
  Route,
  Users,
} from 'lucide-react'
import { Logo } from '@/components/brand/logo'
import { Eyebrow, IconBadge } from '@/components/jr/ui'

export function LandingNav() {
  return (
    <header className="sticky top-0 z-40 border-b bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 md:px-6">
        <Link href="/" aria-label="Jeevan Rakshak home">
          <Logo />
        </Link>
        <nav aria-label="Primary" className="hidden items-center gap-8 text-sm font-medium text-muted-foreground md:flex">
          <a href="#platform" className="hover:text-navy">Platform</a>
          <a href="#how" className="hover:text-navy">How it works</a>
          <a href="#ngos" className="hover:text-navy">For NGOs</a>
          <Link href="/assistant" className="hover:text-navy">Jeevan AI</Link>
        </nav>
        <div className="flex items-center gap-2">
          <Link href="/dashboard" className="hidden h-9 items-center rounded-lg px-3 text-sm font-semibold text-navy hover:bg-secondary sm:flex">
            Sign in
          </Link>
          <Link
            href="/sos"
            className="flex h-9 items-center gap-1.5 rounded-lg bg-danger px-3 text-sm font-semibold text-white hover:brightness-110"
          >
            <Siren className="size-4" aria-hidden="true" /> SOS
          </Link>
        </div>
      </div>
    </header>
  )
}

export function TrustBar() {
  return (
    <section aria-label="Data partners" className="border-y bg-card">
      <div className="mx-auto flex max-w-7xl flex-col items-center gap-4 px-4 py-6 md:flex-row md:justify-between md:px-6">
        <Eyebrow>Live data from trusted sources</Eyebrow>
        <ul className="flex flex-wrap items-center justify-center gap-x-10 gap-y-2 text-sm font-semibold tracking-wide text-muted-foreground/80">
          {['NDMA', 'IMD', 'State SDMAs', 'NCS Seismology', 'CWC Flood', '86 NGOs'].map((s) => (
            <li key={s}>{s}</li>
          ))}
        </ul>
      </div>
    </section>
  )
}

const steps = [
  { n: '01', title: 'Know', body: 'Hyper-local alerts tell you what is happening, how far it is, and what to do — in your language.', icon: Radar },
  { n: '02', title: 'Find safety', body: 'See verified shelters, hospitals and relief centres with live capacity and the safest route.', icon: Route },
  { n: '03', title: 'Get or give help', body: 'Request rescue in seconds, or match your skills and resources with neighbours who need them.', icon: Users },
]

export function HowItWorks() {
  return (
    <section id="how" className="mx-auto max-w-7xl scroll-mt-20 px-4 py-20 md:px-6 md:py-28">
      <div className="max-w-2xl">
        <Eyebrow className="text-teal">How it works</Eyebrow>
        <h2 className="mt-3 text-3xl font-semibold tracking-tight text-balance text-navy md:text-4xl">
          Three steps between uncertainty and safety.
        </h2>
      </div>
      <ol className="mt-12 grid gap-6 md:grid-cols-3">
        {steps.map((s) => (
          <li key={s.n} className="relative rounded-2xl border bg-card p-6">
            <div className="flex items-center justify-between">
              <IconBadge icon={s.icon} tone="teal" />
              <span className="font-mono text-sm text-muted-foreground">{s.n}</span>
            </div>
            <h3 className="mt-6 text-lg font-semibold text-navy">{s.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.body}</p>
          </li>
        ))}
      </ol>
    </section>
  )
}

export function PlatformBento() {
  return (
    <section id="platform" className="scroll-mt-20 bg-navy py-20 text-white md:py-28">
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div className="max-w-2xl">
            <p className="text-[11px] font-semibold tracking-[0.14em] text-[#2cc4b0] uppercase">The platform</p>
            <h2 className="mt-3 text-3xl font-semibold tracking-tight text-balance md:text-4xl">
              Everything you need, before, during and after a disaster.
            </h2>
          </div>
          <Link href="/dashboard" className="inline-flex items-center gap-2 text-sm font-semibold text-[#2cc4b0] hover:underline">
            Open the dashboard <ArrowRight className="size-4" aria-hidden="true" />
          </Link>
        </div>

        <div className="mt-12 grid auto-rows-[minmax(200px,auto)] gap-4 md:grid-cols-3">
          <BentoTile
            href="/map"
            icon={Map}
            title="Interactive safety map"
            body="Safe zones, danger areas, shelters and hospitals — with live capacity and routes."
            className="md:col-span-2 md:row-span-2"
            large
          />
          <BentoTile href="/alerts" icon={BellRing} title="Live disaster alerts" body="Severity-ranked, location-aware, with clear actions." />
          <BentoTile href="/assistant" icon={Bot} title="Jeevan AI" body="Ask anything. Get structured, sourced safety guidance." />
          <BentoTile href="/request-help" icon={LifeBuoy} title="Request help" body="Rescue, medical, food — tracked until it arrives." />
          <BentoTile href="/help-others" icon={HandHeart} title="Community response" body="Volunteer, share resources, verify requests nearby." />
          <BentoTile href="/sos" icon={Siren} title="One-tap SOS" body="Share live location with responders and contacts." danger />
        </div>
      </div>
    </section>
  )
}

function BentoTile({
  href,
  icon: Icon,
  title,
  body,
  className = '',
  large,
  danger,
}: {
  href: string
  icon: React.ComponentType<{ className?: string }>
  title: string
  body: string
  className?: string
  large?: boolean
  danger?: boolean
}) {
  return (
    <Link
      href={href}
      className={`group relative flex flex-col overflow-hidden rounded-2xl border border-white/10 bg-white/[0.04] p-6 transition hover:-translate-y-0.5 hover:border-white/20 hover:bg-white/[0.07] ${className}`}
    >
      {large && (
        <div className="pointer-events-none absolute inset-0 opacity-60">
          <Image src="/images/hero-map.png" alt="" fill sizes="66vw" className="object-cover [mask-image:linear-gradient(to_top,black_20%,transparent)]" />
        </div>
      )}
      <span
        className={`relative flex size-10 items-center justify-center rounded-xl ${danger ? 'bg-danger text-white' : 'bg-white/10 text-[#2cc4b0]'}`}
      >
        <Icon className="size-5" aria-hidden="true" />
      </span>
      <div className="relative mt-auto pt-10">
        <h3 className={`font-semibold ${large ? 'text-2xl' : 'text-lg'}`}>{title}</h3>
        <p className="mt-1.5 max-w-md text-sm leading-relaxed text-white/65">{body}</p>
      </div>
      <ArrowRight className="absolute top-6 right-6 size-4 text-white/40 transition group-hover:translate-x-0.5 group-hover:text-white" aria-hidden="true" />
    </Link>
  )
}

export function NgoBand() {
  return (
    <section id="ngos" className="mx-auto max-w-7xl scroll-mt-20 px-4 py-20 md:px-6 md:py-28">
      <div className="grid overflow-hidden rounded-3xl border bg-teal-tint lg:grid-cols-2">
        <div className="flex flex-col justify-center p-8 md:p-12">
          <Eyebrow className="text-teal">For NGOs & volunteers</Eyebrow>
          <h2 className="mt-3 text-3xl font-semibold tracking-tight text-balance text-navy md:text-4xl">
            Coordinate relief where it is needed most.
          </h2>
          <p className="mt-4 text-muted-foreground text-pretty">
            Verified organisations receive prioritised requests, manage volunteers, and publish transparent
            donation drives — all on one map.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Link href="/support" className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-teal px-5 text-sm font-semibold text-white hover:brightness-110">
              Partner with us <ArrowRight className="size-4" aria-hidden="true" />
            </Link>
            <Link href="/help-others" className="inline-flex h-11 items-center justify-center rounded-xl border border-teal/30 bg-card px-5 text-sm font-semibold text-navy hover:bg-white">
              Become a volunteer
            </Link>
          </div>
        </div>
        <div className="relative min-h-72">
          <Image
            src="/images/volunteers.png"
            alt="Volunteers distributing water and supply kits at a relief centre"
            fill
            sizes="(min-width: 1024px) 50vw, 100vw"
            className="object-cover"
          />
        </div>
      </div>
    </section>
  )
}

export function Footer() {
  return (
    <footer className="border-t bg-card">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 md:grid-cols-[1.5fr_1fr_1fr] md:px-6">
        <div>
          <Logo showTagline />
          <p className="mt-4 max-w-sm text-sm text-muted-foreground">
            Built for citizens, responders and communities across India.
          </p>
        </div>
        <div>
          <Eyebrow>Emergency helplines</Eyebrow>
          <ul className="mt-3 flex flex-col gap-2 text-sm">
            {[
              ['112', 'National emergency'],
              ['1078', 'NDMA disaster helpline'],
              ['108', 'Ambulance'],
            ].map(([n, l]) => (
              <li key={n}>
                <a href={`tel:${n}`} className="flex items-center gap-2 text-navy hover:text-teal">
                  <Phone className="size-3.5" aria-hidden="true" />
                  <span className="font-mono font-semibold">{n}</span>
                  <span className="text-muted-foreground">{l}</span>
                </a>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <Eyebrow>Platform</Eyebrow>
          <ul className="mt-3 flex flex-col gap-2 text-sm text-muted-foreground">
            <li><Link href="/dashboard" className="hover:text-navy">Dashboard</Link></li>
            <li><Link href="/map" className="hover:text-navy">Safety map</Link></li>
            <li><Link href="/alerts" className="hover:text-navy">Alerts</Link></li>
            <li><Link href="/support" className="hover:text-navy">Donate</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t">
        <p className="mx-auto max-w-7xl px-4 py-5 text-xs text-muted-foreground md:px-6">
          {'© 2026 Jeevan Rakshak. A prototype for public safety.'}
        </p>
      </div>
    </footer>
  )
}
