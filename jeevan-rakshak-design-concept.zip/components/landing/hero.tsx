import Image from 'next/image'
import Link from 'next/link'
import { ArrowRight, MapPin, ShieldCheck, Navigation, Sparkles } from 'lucide-react'

export function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 bg-grid [mask-image:radial-gradient(ellipse_at_top,black,transparent_70%)]" aria-hidden="true" />
      <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-4 pt-12 pb-20 md:px-6 lg:grid-cols-[1.05fr_1fr] lg:pt-20 lg:pb-28">
        <div className="animate-fade-up">
          <div className="inline-flex items-center gap-2 rounded-full border bg-card px-3 py-1.5 text-xs font-medium text-muted-foreground shadow-sm">
            <span className="relative flex size-2">
              <span className="absolute inset-0 animate-pulse-ring rounded-full bg-warn" aria-hidden="true" />
              <span className="relative size-2 rounded-full bg-warn" />
            </span>
            Live: 3 active advisories across India
          </div>
          <h1 className="mt-6 text-4xl leading-[1.05] font-semibold tracking-tight text-balance text-navy sm:text-5xl lg:text-6xl">
            Prepare. Protect. <span className="text-teal">Respond.</span>
          </h1>
          <p className="mt-5 max-w-xl text-lg leading-relaxed text-muted-foreground text-pretty">
            Jeevan Rakshak is an intelligent disaster-management platform that helps you stay informed, find
            safety, request assistance and help others when it matters most.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Link
              href="/dashboard"
              className="group inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-navy px-6 text-[15px] font-semibold text-white shadow-lg shadow-navy/20 transition hover:bg-navy-soft"
            >
              Check your safety
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
            </Link>
            <Link
              href="#platform"
              className="inline-flex h-12 items-center justify-center rounded-xl border bg-card px-6 text-[15px] font-semibold text-navy transition hover:bg-secondary"
            >
              Explore the platform
            </Link>
          </div>
          <dl className="mt-10 grid max-w-md grid-cols-3 gap-6 border-t pt-6">
            {[
              ['12.4k', 'People guided'],
              ['340', 'Verified shelters'],
              ['86', 'Partner NGOs'],
            ].map(([v, l]) => (
              <div key={l}>
                <dt className="sr-only">{l}</dt>
                <dd className="font-mono text-2xl font-semibold text-navy">{v}</dd>
                <dd className="mt-0.5 text-xs text-muted-foreground">{l}</dd>
              </div>
            ))}
          </dl>
        </div>

        <div className="relative animate-fade-up [animation-delay:150ms]">
          <div className="relative aspect-square overflow-hidden rounded-[28px] bg-navy shadow-2xl shadow-navy/30 ring-1 ring-navy/10">
            <Image
              src="/images/hero-map.png"
              alt="Stylised map showing your location, a safe zone and a nearby flood-risk area"
              fill
              priority
              sizes="(min-width: 1024px) 560px, 100vw"
              className="object-cover opacity-90"
            />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
              <span className="relative flex size-5">
                <span className="absolute inset-0 animate-pulse-ring rounded-full bg-info" aria-hidden="true" />
                <span className="relative size-5 rounded-full border-[3px] border-white bg-info shadow-lg" />
              </span>
            </div>

            <div className="absolute top-5 left-5 flex items-center gap-2 rounded-xl bg-white/10 px-3 py-2 text-xs font-medium text-white ring-1 ring-white/15 backdrop-blur-md">
              <Sparkles className="size-3.5 text-[#2cc4b0]" aria-hidden="true" />
              AI analysing 14 data sources
              <span className="shimmer h-1 w-10 animate-shimmer rounded-full" aria-hidden="true" />
            </div>
          </div>

          <div className="absolute -bottom-6 -left-4 w-64 rounded-2xl border bg-card/95 p-4 shadow-xl backdrop-blur-md sm:-left-8">
            <div className="flex items-center gap-3">
              <span className="flex size-10 items-center justify-center rounded-full bg-safe-tint text-safe ring-4 ring-safe/10">
                <ShieldCheck className="size-5" aria-hidden="true" />
              </span>
              <div>
                <p className="text-xs font-semibold tracking-wider text-safe uppercase">You are safe</p>
                <p className="flex items-center gap-1 text-sm text-muted-foreground">
                  <MapPin className="size-3" aria-hidden="true" /> Kothrud, Pune
                </p>
              </div>
            </div>
          </div>

          <div className="absolute -top-4 -right-2 hidden w-56 rounded-2xl border bg-card/95 p-4 shadow-xl backdrop-blur-md sm:block md:-right-6">
            <p className="text-[11px] font-semibold tracking-wider text-muted-foreground uppercase">Nearest shelter</p>
            <p className="mt-1 text-sm font-semibold text-navy">Community Relief Centre</p>
            <div className="mt-2 flex items-center justify-between">
              <span className="font-mono text-xs text-muted-foreground">1.2 km · 4 min</span>
              <span className="inline-flex items-center gap-1 rounded-md bg-teal px-2 py-1 text-[11px] font-semibold text-white">
                <Navigation className="size-3" aria-hidden="true" /> Go
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
