'use client'

import { useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import {
  BadgeCheck,
  MapPin,
  Mic,
  Navigation,
  SendHorizonal,
  ShieldCheck,
  Siren,
  ThumbsDown,
  ThumbsUp,
  TriangleAlert,
} from 'lucide-react'
import { LogoMark } from '@/components/brand/logo'
import { Card, Eyebrow, StatusPill } from '@/components/jr/ui'

type Reply = {
  status: { tone: 'safe' | 'warn' | 'danger'; label: string }
  info: string
  actions: string[]
  places?: { name: string; distance: string }[]
  urgent?: boolean
}

type Message = { id: number; role: 'user' | 'ai'; text?: string; reply?: Reply }

const suggestions = ['Is my area safe?', 'Find nearest shelter', 'What to do in a flood?', 'I am trapped, need help']

function respond(q: string): Reply {
  const t = q.toLowerCase()
  if (/(trapped|injur|help me|drown|stuck|bleed)/.test(t)) {
    return {
      status: { tone: 'danger', label: 'Emergency detected' },
      info: 'This sounds urgent. Your live location can be shared with responders and your emergency contacts in one tap.',
      actions: ['Stay where rescuers can see or hear you', 'Conserve phone battery', 'Signal with a torch or bright cloth'],
      urgent: true,
    }
  }
  if (/flood/.test(t)) {
    return {
      status: { tone: 'warn', label: 'Flood guidance' },
      info: 'A flood warning is active on the Mula-Mutha riverbanks, 6.4 km from you. Your street is not in the affected zone.',
      actions: [
        'Move to the highest floor and switch off mains power',
        'Never walk or drive through flowing water — 15 cm can knock you down',
        'Keep drinking water, medicines and documents in a dry bag',
      ],
      places: [{ name: 'Kothrud Community Relief Centre', distance: '1.2 km' }],
    }
  }
  if (/(shelter|safe place|where)/.test(t)) {
    return {
      status: { tone: 'safe', label: '6 shelters nearby' },
      info: 'The closest verified shelter has 58 free spaces and offers food, water and medical aid.',
      actions: ['Carry your ID and essential medicines', 'Inform family of your destination'],
      places: [
        { name: 'Kothrud Community Relief Centre', distance: '1.2 km' },
        { name: 'MIT School Shelter Hall', distance: '2.1 km' },
      ],
    }
  }
  return {
    status: { tone: 'safe', label: 'Safe — low risk' },
    info: 'No hazards within 2 km of Kothrud. A flood warning is active 6.4 km away and heavy rain is expected tonight.',
    actions: ['Stay indoors after 8 PM if rain intensifies', 'Charge your phone and power bank', 'Avoid riverside roads'],
    places: [{ name: 'Kothrud Community Relief Centre', distance: '1.2 km' }],
  }
}

export function Assistant() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 0,
      role: 'ai',
      reply: {
        status: { tone: 'safe', label: 'You are safe' },
        info: 'Namaste Aarav, I am Jeevan, your safety assistant. I am using your location in Kothrud, Pune to personalise answers.',
        actions: ['Ask about alerts, shelters, or what to do in an emergency'],
      },
    },
  ])
  const [input, setInput] = useState('')
  const [thinking, setThinking] = useState(false)
  const endRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' })
  }, [messages, thinking])

  function send(text: string) {
    const q = text.trim()
    if (!q || thinking) return
    setMessages((m) => [...m, { id: Date.now(), role: 'user', text: q }])
    setInput('')
    setThinking(true)
    setTimeout(() => {
      setMessages((m) => [...m, { id: Date.now() + 1, role: 'ai', reply: respond(q) }])
      setThinking(false)
    }, 1100)
  }

  return (
    <div className="mx-auto grid max-w-6xl gap-6 lg:grid-cols-[1fr_280px]">
      <section className="flex h-[calc(100dvh-4rem-8rem)] flex-col overflow-hidden rounded-2xl border bg-card lg:h-[calc(100dvh-4rem-4rem)]">
        <header className="flex items-center gap-3 border-b px-5 py-4">
          <span className="flex size-10 items-center justify-center rounded-xl bg-navy">
            <LogoMark className="size-6 text-white" />
          </span>
          <div className="flex-1">
            <h1 className="font-semibold">Jeevan AI</h1>
            <p className="text-xs text-muted-foreground">Your intelligent safety assistant</p>
          </div>
          <span className="hidden items-center gap-1.5 rounded-full bg-teal-tint px-2.5 py-1 text-xs font-medium text-teal sm:inline-flex">
            <MapPin className="size-3" aria-hidden="true" /> Using your location
          </span>
        </header>

        <div className="flex-1 overflow-y-auto bg-background/60 px-4 py-6 md:px-6" aria-live="polite">
          <ul className="flex flex-col gap-5">
            {messages.map((m) =>
              m.role === 'user' ? (
                <li key={m.id} className="flex animate-fade-up justify-end">
                  <p className="max-w-[80%] rounded-2xl rounded-br-md bg-navy px-4 py-2.5 text-sm text-white">{m.text}</p>
                </li>
              ) : (
                <li key={m.id} className="flex animate-fade-up gap-3">
                  <span className="mt-1 flex size-8 shrink-0 items-center justify-center rounded-lg bg-teal">
                    <LogoMark className="size-5 text-white" />
                  </span>
                  {m.reply && <ReplyCard reply={m.reply} />}
                </li>
              ),
            )}
            {thinking && (
              <li className="flex gap-3">
                <span className="mt-1 flex size-8 shrink-0 items-center justify-center rounded-lg bg-teal">
                  <LogoMark className="size-5 text-white" />
                </span>
                <div className="flex flex-col gap-2 rounded-2xl rounded-tl-md border bg-card px-4 py-3">
                  <span className="text-xs text-muted-foreground">Checking alerts near you…</span>
                  <span className="shimmer h-1.5 w-40 animate-shimmer rounded-full bg-teal-tint" aria-hidden="true" />
                </div>
              </li>
            )}
          </ul>
          <div ref={endRef} />
        </div>

        <div className="border-t p-3 md:p-4">
          <div className="no-scrollbar mb-3 flex gap-2 overflow-x-auto">
            {suggestions.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => send(s)}
                className="shrink-0 rounded-full border bg-card px-3 py-1.5 text-xs font-medium text-navy transition hover:border-teal/40 hover:bg-teal-tint"
              >
                {s}
              </button>
            ))}
          </div>
          <form
            onSubmit={(e) => {
              e.preventDefault()
              send(input)
            }}
            className="flex items-center gap-2 rounded-xl border bg-background p-1.5 focus-within:ring-2 focus-within:ring-ring"
          >
            <label htmlFor="ask" className="sr-only">Ask Jeevan AI</label>
            <input
              id="ask"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && (e.nativeEvent.isComposing || e.keyCode === 229)) e.preventDefault()
              }}
              placeholder="Ask about safety, shelters, alerts…"
              className="h-10 flex-1 bg-transparent px-2 text-sm outline-none placeholder:text-muted-foreground"
            />
            <button type="button" className="flex size-10 items-center justify-center rounded-lg text-muted-foreground hover:bg-secondary" aria-label="Voice input">
              <Mic className="size-4" aria-hidden="true" />
            </button>
            <button
              type="submit"
              disabled={!input.trim() || thinking}
              className="flex size-10 items-center justify-center rounded-lg bg-navy text-white transition disabled:opacity-40"
              aria-label="Send"
            >
              <SendHorizonal className="size-4" aria-hidden="true" />
            </button>
          </form>
        </div>
      </section>

      <aside className="hidden flex-col gap-4 lg:flex">
        <Card className="p-5">
          <Eyebrow>Context</Eyebrow>
          <ul className="mt-4 flex flex-col gap-4 text-sm">
            <li className="flex items-center gap-3">
              <MapPin className="size-4 text-info" aria-hidden="true" />
              <span><span className="block font-medium">Location on</span><span className="text-xs text-muted-foreground">Kothrud, Pune</span></span>
            </li>
            <li className="flex items-center gap-3">
              <TriangleAlert className="size-4 text-warn" aria-hidden="true" />
              <span><span className="block font-medium">2 active alerts</span><span className="text-xs text-muted-foreground">Nearest 6.4 km</span></span>
            </li>
            <li className="flex items-center gap-3">
              <ShieldCheck className="size-4 text-safe" aria-hidden="true" />
              <span><span className="block font-medium">Status: Safe</span><span className="text-xs text-muted-foreground">Low risk</span></span>
            </li>
          </ul>
        </Card>
        <Card className="p-5">
          <Eyebrow>Sources used</Eyebrow>
          <ul className="mt-3 flex flex-wrap gap-2">
            {['IMD', 'NDMA', 'CWC', 'PMC', 'Shelter registry'].map((s) => (
              <li key={s} className="flex items-center gap-1 rounded-md bg-secondary px-2 py-1 text-xs font-medium">
                <BadgeCheck className="size-3 text-info" aria-hidden="true" /> {s}
              </li>
            ))}
          </ul>
          <p className="mt-4 text-xs leading-relaxed text-muted-foreground">
            Jeevan AI provides guidance, not a substitute for official instructions. In danger, call 112.
          </p>
        </Card>
      </aside>
    </div>
  )
}

function ReplyCard({ reply }: { reply: Reply }) {
  return (
    <div className="max-w-xl flex-1 rounded-2xl rounded-tl-md border bg-card p-4 shadow-sm">
      <StatusPill tone={reply.status.tone}>{reply.status.label}</StatusPill>
      <p className="mt-3 text-sm leading-relaxed">{reply.info}</p>

      {reply.urgent && (
        <Link
          href="/sos"
          className="mt-3 flex items-center justify-between gap-2 rounded-xl bg-danger px-4 py-3 text-sm font-semibold text-white hover:brightness-110"
        >
          <span className="flex items-center gap-2"><Siren className="size-4" aria-hidden="true" /> Open SOS now</span>
          <span className="font-mono text-xs opacity-80">or call 112</span>
        </Link>
      )}

      <div className="mt-4">
        <p className="text-[11px] font-semibold tracking-wider text-muted-foreground uppercase">Recommended actions</p>
        <ul className="mt-2 flex flex-col gap-1.5">
          {reply.actions.map((a, i) => (
            <li key={a} className="flex gap-2 text-sm">
              <span className="flex size-5 shrink-0 items-center justify-center rounded-full bg-teal-tint font-mono text-[11px] font-semibold text-teal">{i + 1}</span>
              {a}
            </li>
          ))}
        </ul>
      </div>

      {reply.places && (
        <div className="mt-4">
          <p className="text-[11px] font-semibold tracking-wider text-muted-foreground uppercase">Nearby safe locations</p>
          <ul className="mt-2 flex flex-col gap-2">
            {reply.places.map((p) => (
              <li key={p.name} className="flex items-center justify-between gap-2 rounded-lg bg-secondary/70 px-3 py-2">
                <span className="text-sm font-medium">{p.name} <span className="font-mono text-xs text-muted-foreground">· {p.distance}</span></span>
                <Link href="/map" className="flex items-center gap-1 text-xs font-semibold text-teal hover:underline">
                  <Navigation className="size-3" aria-hidden="true" /> Navigate
                </Link>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="mt-4 flex items-center justify-between border-t pt-3 text-xs text-muted-foreground">
        <span>Sources: IMD · NDMA</span>
        <span className="flex gap-1">
          <button type="button" className="rounded p-1 hover:bg-secondary" aria-label="Helpful"><ThumbsUp className="size-3.5" /></button>
          <button type="button" className="rounded p-1 hover:bg-secondary" aria-label="Not helpful"><ThumbsDown className="size-3.5" /></button>
        </span>
      </div>
    </div>
  )
}
