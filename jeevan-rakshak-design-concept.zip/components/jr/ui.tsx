import type { LucideIcon } from 'lucide-react'
import {
  CloudRain,
  Flame,
  Mountain,
  Activity,
  Tornado,
  Waves,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import type { Hazard, Severity } from '@/lib/data'

export const hazardIcon: Record<Hazard, LucideIcon> = {
  cyclone: Tornado,
  flood: Waves,
  rain: CloudRain,
  earthquake: Activity,
  fire: Flame,
  landslide: Mountain,
}

export const severityStyles: Record<
  Severity,
  { label: string; pill: string; rail: string; tint: string; text: string }
> = {
  critical: {
    label: 'Critical',
    pill: 'bg-danger text-white',
    rail: 'before:bg-danger',
    tint: 'bg-danger-tint',
    text: 'text-danger',
  },
  high: {
    label: 'High',
    pill: 'bg-warn text-white',
    rail: 'before:bg-warn',
    tint: 'bg-warn-tint',
    text: 'text-warn',
  },
  moderate: {
    label: 'Moderate',
    pill: 'bg-warn-tint text-warn ring-1 ring-warn/30',
    rail: 'before:bg-warn/60',
    tint: 'bg-card',
    text: 'text-warn',
  },
  advisory: {
    label: 'Advisory',
    pill: 'bg-info-tint text-info ring-1 ring-info/25',
    rail: 'before:bg-info',
    tint: 'bg-card',
    text: 'text-info',
  },
}

type Tone = 'safe' | 'warn' | 'danger' | 'info' | 'teal' | 'neutral'

const toneClasses: Record<Tone, string> = {
  safe: 'bg-safe-tint text-safe',
  warn: 'bg-warn-tint text-warn',
  danger: 'bg-danger-tint text-danger',
  info: 'bg-info-tint text-info',
  teal: 'bg-teal-tint text-teal',
  neutral: 'bg-secondary text-muted-foreground',
}

export function StatusPill({
  tone,
  children,
  dot = true,
  className,
}: {
  tone: Tone
  children: React.ReactNode
  dot?: boolean
  className?: string
}) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold tracking-wider uppercase',
        toneClasses[tone],
        className,
      )}
    >
      {dot && <span className="size-1.5 rounded-full bg-current" aria-hidden="true" />}
      {children}
    </span>
  )
}

export function IconBadge({
  icon: Icon,
  tone,
  className,
  size = 'md',
}: {
  icon: LucideIcon
  tone: Tone
  className?: string
  size?: 'sm' | 'md' | 'lg'
}) {
  return (
    <span
      className={cn(
        'inline-flex shrink-0 items-center justify-center rounded-xl',
        toneClasses[tone],
        size === 'sm' && 'size-8 [&_svg]:size-4',
        size === 'md' && 'size-10 [&_svg]:size-5',
        size === 'lg' && 'size-12 [&_svg]:size-6',
        className,
      )}
    >
      <Icon aria-hidden="true" />
    </span>
  )
}

export function Card({ className, children }: { className?: string; children: React.ReactNode }) {
  return (
    <div
      className={cn(
        'rounded-2xl border bg-card shadow-[0_1px_2px_rgb(11_31_58/0.04)]',
        className,
      )}
    >
      {children}
    </div>
  )
}

export function Eyebrow({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <p className={cn('text-[11px] font-semibold tracking-[0.14em] text-muted-foreground uppercase', className)}>
      {children}
    </p>
  )
}

export function PageHeader({
  title,
  description,
  actions,
}: {
  title: string
  description?: string
  actions?: React.ReactNode
}) {
  return (
    <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight text-balance md:text-3xl">{title}</h1>
        {description && <p className="mt-1.5 text-sm text-muted-foreground text-pretty md:text-base">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  )
}
