'use client'

import { useState } from 'react'
import Link from 'next/link'
import { BadgeCheck, Navigation, TrendingUp } from 'lucide-react'
import { alerts, type Alert, type Hazard } from '@/lib/data'
import { cn } from '@/lib/utils'
import { Card, PageHeader, hazardIcon, severityStyles } from '@/components/jr/ui'

const filters: { id: 'all' | Hazard; label: string }[] = [
  { id: 'all', label: 'All' },
  { id: 'cyclone', label: 'Cyclone' },
  { id: 'flood', label: 'Flood' },
  { id: 'rain', label: 'Heavy rain' },
  { id: 'earthquake', label: 'Earthquake' },
  { id: 'fire', label: 'Fire' },
  { id: 'landslide', label: 'Landslide' },
]

export function AlertsView() {
  const [filter, setFilter] = useState<'all' | Hazard>('all')
  const list = alerts.filter((a) => filter === 'all' || a.hazard === filter)
  const critical = list.filter((a) => a.severity === 'critical')
  const rest = list.filter((a) => a.severity !== 'critical')

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6">
      <PageHeader
        title="Disaster alerts"
        description="Verified, location-aware warnings ranked by severity."
        actions={
          <span className="inline-flex items-center gap-2 rounded-lg border bg-card px-3 py-2 text-sm">
            <span className="size-2 rounded-full bg-safe" aria-hidden="true" />
            Near me · 150 km
          </span>
        }
      />

      <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4" role="tablist" aria-label="Filter by hazard">
        {filters.map((f) => {
          const Icon = f.id === 'all' ? null : hazardIcon[f.id]
          const active = filter === f.id
          return (
            <button
              key={f.id}
              role="tab"
              aria-selected={active}
              onClick={() => setFilter(f.id)}
              className={cn(
                'inline-flex shrink-0 items-center gap-1.5 rounded-full border px-3.5 py-2 text-sm font-medium transition',
                active ? 'border-navy bg-navy text-white' : 'bg-card text-muted-foreground hover:text-navy',
              )}
            >
              {Icon && <Icon className="size-4" aria-hidden="true" />}
              {f.label}
            </button>
          )
        })}
      </div>

      {critical.map((a) => (
        <CriticalAlert key={a.id} alert={a} />
      ))}

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {rest.map((a, i) => (
          <AlertCard key={a.id} alert={a} index={i} />
        ))}
      </div>

      {list.length === 0 && (
        <Card className="p-10 text-center text-sm text-muted-foreground">No active alerts of this type near you.</Card>
      )}
    </div>
  )
}

function CriticalAlert({ alert }: { alert: Alert }) {
  const Icon = hazardIcon[alert.hazard]
  return (
    <article className="relative overflow-hidden rounded-2xl border border-danger/30 bg-danger-tint p-6 md:p-7">
      <div className="absolute inset-y-0 left-0 w-1.5 bg-danger" aria-hidden="true" />
      <div className="flex flex-col gap-6 lg:flex-row lg:items-start">
        <div className="flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-danger px-2.5 py-1 text-[11px] font-bold tracking-wider text-white uppercase">
              <span className="relative flex size-1.5">
                <span className="absolute inset-0 animate-pulse-ring rounded-full bg-white" aria-hidden="true" />
                <span className="relative size-1.5 rounded-full bg-white" />
              </span>
              Critical
            </span>
            <span className="inline-flex items-center gap-1 text-xs font-semibold text-danger">
              <TrendingUp className="size-3.5" aria-hidden="true" /> {alert.status}
            </span>
          </div>
          <div className="mt-4 flex items-start gap-3">
            <span className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-danger text-white">
              <Icon className="size-6" aria-hidden="true" />
            </span>
            <div>
              <h2 className="text-xl font-semibold text-navy text-balance md:text-2xl">{alert.title}</h2>
              <p className="mt-1 font-mono text-xs text-muted-foreground">
                {alert.area} · Issued {alert.issued} · {alert.distance} away
              </p>
            </div>
          </div>
        </div>
        <div className="rounded-xl bg-card p-4 lg:w-96">
          <p className="text-[11px] font-semibold tracking-wider text-danger uppercase">What to do now</p>
          <ol className="mt-3 flex flex-col gap-2.5">
            {alert.instructions.map((s, i) => (
              <li key={s} className="flex items-start gap-3 text-sm">
                <span className="flex size-5 shrink-0 items-center justify-center rounded-full bg-danger font-mono text-[11px] font-semibold text-white">
                  {i + 1}
                </span>
                {s}
              </li>
            ))}
          </ol>
        </div>
      </div>
      <div className="mt-6 flex flex-col gap-3 border-t border-danger/15 pt-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex gap-2">
          <Link href="/map" className="inline-flex h-10 items-center gap-2 rounded-lg bg-danger px-4 text-sm font-semibold text-white hover:brightness-110">
            <Navigation className="size-4" aria-hidden="true" /> View safe route
          </Link>
          <button type="button" className="h-10 rounded-lg border border-danger/25 bg-card px-4 text-sm font-semibold text-navy hover:bg-white">
            Full advisory
          </button>
        </div>
        <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <BadgeCheck className="size-4 text-info" aria-hidden="true" /> Verified · Source: {alert.source}
        </p>
      </div>
    </article>
  )
}

function AlertCard({ alert, index }: { alert: Alert; index: number }) {
  const s = severityStyles[alert.severity]
  const Icon = hazardIcon[alert.hazard]
  return (
    <article
      style={{ animationDelay: `${index * 60}ms` }}
      className={cn(
        'relative flex animate-fade-up flex-col overflow-hidden rounded-2xl border p-5 before:absolute before:inset-y-0 before:left-0 before:w-1',
        s.rail,
        s.tint,
      )}
    >
      <div className="flex items-center justify-between">
        <span className={cn('flex size-10 items-center justify-center rounded-xl bg-card ring-1 ring-border', s.text)}>
          <Icon className="size-5" aria-hidden="true" />
        </span>
        <span className={cn('rounded-full px-2.5 py-1 text-[11px] font-semibold tracking-wider uppercase', s.pill)}>
          {s.label}
        </span>
      </div>
      <h3 className="mt-4 font-semibold text-navy text-pretty">{alert.title}</h3>
      <p className="mt-1 font-mono text-xs text-muted-foreground">
        {alert.area} · {alert.issued} · {alert.distance}
      </p>
      <ul className="mt-4 flex flex-col gap-1.5 text-sm text-muted-foreground">
        {alert.instructions.map((i, n) => (
          <li key={i} className="flex gap-2">
            <span className="font-mono text-xs text-navy/60">{n + 1}</span> {i}
          </li>
        ))}
      </ul>
      <div className="mt-auto flex items-center justify-between pt-5 text-xs text-muted-foreground">
        <span className="flex items-center gap-1">
          <BadgeCheck className="size-3.5 text-info" aria-hidden="true" /> {alert.source}
        </span>
        <span className="rounded-md bg-secondary px-2 py-0.5 font-medium">{alert.status}</span>
      </div>
    </article>
  )
}
