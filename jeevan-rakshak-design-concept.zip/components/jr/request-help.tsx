'use client'

import { useState } from 'react'
import Link from 'next/link'
import {
  BadgeCheck,
  Check,
  Copy,
  Flame,
  HeartPulse,
  Home,
  LocateFixed,
  MessageSquare,
  Minus,
  MoreHorizontal,
  Phone,
  Plus,
  Siren,
  UtensilsCrossed,
  Waves,
  CircleAlert,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Card, Eyebrow, PageHeader, StatusPill } from '@/components/jr/ui'

const types = [
  { id: 'flood', label: 'Flood', icon: Waves },
  { id: 'medical', label: 'Medical', icon: HeartPulse },
  { id: 'fire', label: 'Fire', icon: Flame },
  { id: 'trapped', label: 'Trapped', icon: CircleAlert },
  { id: 'food', label: 'Food', icon: UtensilsCrossed },
  { id: 'other', label: 'Other', icon: MoreHorizontal },
]

const urgencies = [
  { id: 'low', label: 'Low', cls: 'data-[on=true]:bg-info data-[on=true]:text-white' },
  { id: 'medium', label: 'Medium', cls: 'data-[on=true]:bg-warn/80 data-[on=true]:text-white' },
  { id: 'high', label: 'High', cls: 'data-[on=true]:bg-warn data-[on=true]:text-white' },
  { id: 'critical', label: 'Critical', cls: 'data-[on=true]:bg-danger data-[on=true]:text-white' },
]

const needs = ['Rescue', 'Medical', 'Food', 'Water', 'Shelter', 'Transport']

export function RequestHelp() {
  const [type, setType] = useState('flood')
  const [people, setPeople] = useState(4)
  const [urgency, setUrgency] = useState('high')
  const [selectedNeeds, setSelectedNeeds] = useState<string[]>(['Rescue', 'Water'])
  const [submitted, setSubmitted] = useState(false)

  if (submitted) return <RequestStatus onReset={() => setSubmitted(false)} />

  const toggleNeed = (n: string) =>
    setSelectedNeeds((s) => (s.includes(n) ? s.filter((x) => x !== n) : [...s, n]))

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-6">
      <PageHeader title="Request assistance" description="Tell us what you need. Verified responders near you will be notified." />

      <Link
        href="/sos"
        className="flex items-center gap-3 rounded-xl border border-danger/25 bg-danger-tint px-4 py-3 text-sm text-danger transition hover:border-danger/50"
      >
        <Siren className="size-4 shrink-0" aria-hidden="true" />
        <span className="flex-1 font-medium">If life is in immediate danger, use SOS instead.</span>
        <span className="font-semibold">Open SOS</span>
      </Link>

      <Card className="p-5 md:p-7">
        <form
          onSubmit={(e) => {
            e.preventDefault()
            setSubmitted(true)
          }}
          className="flex flex-col gap-7"
        >
          <fieldset>
            <legend><Eyebrow>Emergency type</Eyebrow></legend>
            <div className="mt-3 grid grid-cols-3 gap-2 sm:grid-cols-6">
              {types.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  aria-pressed={type === t.id}
                  onClick={() => setType(t.id)}
                  className={cn(
                    'flex flex-col items-center gap-2 rounded-xl border p-3 text-xs font-medium transition',
                    type === t.id ? 'border-navy bg-navy text-white' : 'hover:border-navy/30 hover:bg-secondary',
                  )}
                >
                  <t.icon className="size-5" aria-hidden="true" />
                  {t.label}
                </button>
              ))}
            </div>
          </fieldset>

          <div>
            <Eyebrow>Current location</Eyebrow>
            <div className="mt-3 flex flex-col gap-2 sm:flex-row">
              <div className="flex flex-1 items-center gap-2 rounded-lg border bg-safe-tint/50 px-3 py-2.5 text-sm">
                <LocateFixed className="size-4 text-safe" aria-hidden="true" />
                <span className="flex-1">Lane 7, Kothrud, Pune</span>
                <span className="text-xs font-medium text-safe">Auto-detected</span>
              </div>
              <Link href="/map" className="flex h-11 items-center justify-center rounded-lg border px-4 text-sm font-medium hover:bg-secondary">
                Adjust on map
              </Link>
            </div>
          </div>

          <div className="grid gap-7 sm:grid-cols-2">
            <div>
              <Eyebrow>Number of people</Eyebrow>
              <div className="mt-3 inline-flex items-center rounded-lg border">
                <button type="button" onClick={() => setPeople((p) => Math.max(1, p - 1))} className="flex size-11 items-center justify-center hover:bg-secondary" aria-label="Decrease">
                  <Minus className="size-4" />
                </button>
                <span className="w-12 text-center font-mono text-lg font-semibold" aria-live="polite">{people}</span>
                <button type="button" onClick={() => setPeople((p) => Math.min(99, p + 1))} className="flex size-11 items-center justify-center hover:bg-secondary" aria-label="Increase">
                  <Plus className="size-4" />
                </button>
              </div>
              <label className="mt-3 flex items-center gap-2 text-sm text-muted-foreground">
                <input type="checkbox" defaultChecked className="size-4 accent-teal" />
                Includes children, elderly or disabled
              </label>
            </div>
            <fieldset>
              <legend><Eyebrow>Urgency</Eyebrow></legend>
              <div className="mt-3 grid grid-cols-4 gap-1 rounded-lg bg-secondary p-1">
                {urgencies.map((u) => (
                  <button
                    key={u.id}
                    type="button"
                    data-on={urgency === u.id}
                    aria-pressed={urgency === u.id}
                    onClick={() => setUrgency(u.id)}
                    className={cn('rounded-md py-2 text-xs font-semibold text-muted-foreground transition', u.cls)}
                  >
                    {u.label}
                  </button>
                ))}
              </div>
            </fieldset>
          </div>

          <fieldset>
            <legend><Eyebrow>Required assistance</Eyebrow></legend>
            <div className="mt-3 flex flex-wrap gap-2">
              {needs.map((n) => {
                const on = selectedNeeds.includes(n)
                return (
                  <button
                    key={n}
                    type="button"
                    aria-pressed={on}
                    onClick={() => toggleNeed(n)}
                    className={cn(
                      'inline-flex items-center gap-1.5 rounded-full border px-3.5 py-2 text-sm font-medium transition',
                      on ? 'border-teal bg-teal-tint text-teal' : 'hover:bg-secondary',
                    )}
                  >
                    {on && <Check className="size-3.5" aria-hidden="true" />}
                    {n}
                  </button>
                )
              })}
            </div>
          </fieldset>

          <div>
            <label htmlFor="desc"><Eyebrow>Description (optional)</Eyebrow></label>
            <textarea
              id="desc"
              rows={3}
              placeholder="Water is rising on the ground floor. We are on the first floor with an elderly parent."
              className="mt-3 w-full rounded-lg border bg-background px-3 py-2.5 text-sm outline-none placeholder:text-muted-foreground focus-visible:ring-2 focus-visible:ring-ring"
            />
          </div>

          <button
            type="submit"
            className={cn(
              'h-12 rounded-xl text-[15px] font-semibold text-white shadow-lg transition hover:brightness-110',
              urgency === 'critical' ? 'bg-danger shadow-danger/25' : 'bg-navy shadow-navy/20',
            )}
          >
            Request help
          </button>
        </form>
      </Card>
    </div>
  )
}

const timeline = [
  { label: 'Submitted', time: '14:32', state: 'done' },
  { label: 'Verified', time: '14:34', state: 'done' },
  { label: 'Helper assigned', time: '14:36', state: 'done' },
  { label: 'En route', time: 'ETA 12 min', state: 'current' },
  { label: 'Assistance delivered', time: '', state: 'todo' },
]

function RequestStatus({ onReset }: { onReset: () => void }) {
  return (
    <div className="mx-auto flex max-w-3xl animate-fade-up flex-col gap-6">
      <Card className="relative overflow-hidden p-6 md:p-8">
        <div className="absolute inset-x-0 top-0 h-1 bg-teal" aria-hidden="true" />
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <span className="flex size-12 items-center justify-center rounded-full bg-teal text-white">
              <Check className="size-6" aria-hidden="true" />
            </span>
            <div>
              <h1 className="text-xl font-semibold">Request received</h1>
              <p className="text-sm text-muted-foreground">Help is on the way. Stay where you are.</p>
            </div>
          </div>
          <button type="button" className="inline-flex items-center gap-2 self-start rounded-lg border px-3 py-2 font-mono text-sm hover:bg-secondary">
            JR-26-08812 <Copy className="size-3.5" aria-hidden="true" />
          </button>
        </div>

        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          <div className="rounded-xl bg-secondary/60 p-4">
            <Eyebrow>Status</Eyebrow>
            <StatusPill tone="info" className="mt-2">In progress</StatusPill>
          </div>
          <div className="rounded-xl bg-secondary/60 p-4">
            <Eyebrow>Assigned to</Eyebrow>
            <div className="mt-2 flex items-center justify-between gap-2">
              <p className="flex items-center gap-1 text-sm font-semibold">
                Seva Relief Foundation <BadgeCheck className="size-4 text-info" aria-label="Verified" />
              </p>
              <div className="flex gap-1">
                <span className="flex size-8 items-center justify-center rounded-lg bg-card ring-1 ring-border" aria-label="Call"><Phone className="size-3.5" /></span>
                <span className="flex size-8 items-center justify-center rounded-lg bg-card ring-1 ring-border" aria-label="Chat"><MessageSquare className="size-3.5" /></span>
              </div>
            </div>
          </div>
        </div>
      </Card>

      <Card className="p-6 md:p-8">
        <h2 className="font-semibold">Progress</h2>
        <ol className="mt-5 flex flex-col">
          {timeline.map((s, i) => (
            <li key={s.label} className="relative flex gap-4 pb-6 last:pb-0">
              {i < timeline.length - 1 && (
                <span className={cn('absolute top-6 left-[11px] h-full w-0.5', s.state === 'done' ? 'bg-teal' : 'bg-border')} aria-hidden="true" />
              )}
              <span
                className={cn(
                  'relative z-10 flex size-6 shrink-0 items-center justify-center rounded-full',
                  s.state === 'done' && 'bg-teal text-white',
                  s.state === 'current' && 'bg-card ring-2 ring-teal',
                  s.state === 'todo' && 'bg-card ring-2 ring-border',
                )}
              >
                {s.state === 'done' && <Check className="size-3.5" aria-hidden="true" />}
                {s.state === 'current' && <span className="size-2 animate-pulse rounded-full bg-teal" />}
              </span>
              <div className="flex flex-1 items-center justify-between">
                <span className={cn('text-sm font-medium', s.state === 'todo' && 'text-muted-foreground')}>{s.label}</span>
                <span className="font-mono text-xs text-muted-foreground">{s.time}</span>
              </div>
            </li>
          ))}
        </ol>
        <div className="mt-6 flex gap-2 border-t pt-5">
          <button type="button" className="h-10 flex-1 rounded-lg bg-navy text-sm font-semibold text-white">Share status</button>
          <button type="button" onClick={onReset} className="h-10 flex-1 rounded-lg border text-sm font-semibold hover:bg-secondary">Cancel request</button>
        </div>
      </Card>

      <Link href="/dashboard" className="flex items-center justify-center gap-2 text-sm font-medium text-muted-foreground hover:text-navy">
        <Home className="size-4" aria-hidden="true" /> Back to dashboard
      </Link>
    </div>
  )
}
