'use client'

import { useState } from 'react'
import Link from 'next/link'
import {
  ArrowRight,
  Check,
  Droplets,
  HandHeart,
  HeartPulse,
  Home,
  LifeBuoy,
  MapPin,
  UtensilsCrossed,
  Users,
} from 'lucide-react'
import { helpRequests, type HelpRequest } from '@/lib/data'
import { cn } from '@/lib/utils'
import { Card, Eyebrow, PageHeader, StatusPill } from '@/components/jr/ui'

const typeIcon = {
  Food: UtensilsCrossed,
  Medical: HeartPulse,
  Shelter: Home,
  Rescue: LifeBuoy,
  Water: Droplets,
}

const urgencyTone = { Critical: 'danger', High: 'warn', Medium: 'info', Low: 'neutral' } as const
const filters = ['All', 'Rescue', 'Medical', 'Food', 'Shelter', 'Water'] as const

export function HelpOthers() {
  const [filter, setFilter] = useState<(typeof filters)[number]>('All')
  const [accepted, setAccepted] = useState<string[]>([])
  const list = helpRequests.filter((r) => filter === 'All' || r.type === filter)

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6">
      <PageHeader title="Community response" description="How would you like to participate today?" />

      <div className="grid gap-4 md:grid-cols-2">
        <Link href="/request-help" className="group rounded-2xl border bg-card p-6 transition hover:-translate-y-0.5 hover:shadow-md">
          <span className="flex size-12 items-center justify-center rounded-xl bg-info-tint text-info"><LifeBuoy className="size-6" aria-hidden="true" /></span>
          <h2 className="mt-5 text-lg font-semibold">I need help</h2>
          <p className="mt-1 text-sm text-muted-foreground">Request rescue, food, shelter or medical aid.</p>
          <span className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-navy">
            Request help <ArrowRight className="size-4 transition group-hover:translate-x-0.5" aria-hidden="true" />
          </span>
        </Link>
        <div className="rounded-2xl border border-teal/30 bg-teal p-6 text-white">
          <span className="flex size-12 items-center justify-center rounded-xl bg-white/15"><HandHeart className="size-6" aria-hidden="true" /></span>
          <h2 className="mt-5 text-lg font-semibold">I want to help</h2>
          <p className="mt-1 text-sm text-white/80">See nearby requests and offer your time or resources.</p>
          <div className="mt-5 flex gap-6 font-mono text-sm">
            <span><span className="text-xl font-semibold">{helpRequests.length}</span> open nearby</span>
            <span><span className="text-xl font-semibold">38</span> volunteers active</span>
          </div>
        </div>
      </div>

      <section aria-labelledby="nearby">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <Eyebrow><span id="nearby">Nearby requests</span></Eyebrow>
          <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 md:mx-0 md:px-0">
            {filters.map((f) => (
              <button
                key={f}
                type="button"
                aria-pressed={filter === f}
                onClick={() => setFilter(f)}
                className={cn(
                  'shrink-0 rounded-full border px-3 py-1.5 text-sm font-medium transition',
                  filter === f ? 'border-navy bg-navy text-white' : 'bg-card text-muted-foreground hover:text-navy',
                )}
              >
                {f}
              </button>
            ))}
          </div>
        </div>
        <ul className="mt-4 grid gap-3 lg:grid-cols-2">
          {list.map((r) => (
            <RequestCard
              key={r.id}
              request={r}
              accepted={accepted.includes(r.id)}
              onAccept={() => setAccepted((a) => (a.includes(r.id) ? a : [...a, r.id]))}
            />
          ))}
        </ul>
      </section>
    </div>
  )
}

function RequestCard({ request: r, accepted, onAccept }: { request: HelpRequest; accepted: boolean; onAccept: () => void }) {
  const Icon = typeIcon[r.type]
  return (
    <li>
      <Card className={cn('flex h-full flex-col gap-4 p-5 transition', r.urgency === 'Critical' && 'border-danger/30')}>
        <div className="flex items-start gap-3">
          <span className={cn('flex size-10 shrink-0 items-center justify-center rounded-xl', r.urgency === 'Critical' ? 'bg-danger-tint text-danger' : 'bg-secondary text-navy')}>
            <Icon className="size-5" aria-hidden="true" />
          </span>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <StatusPill tone={urgencyTone[r.urgency]}>{r.urgency}</StatusPill>
              <span className="text-xs text-muted-foreground">{r.type}</span>
            </div>
            <h3 className="mt-2 font-semibold text-pretty">{r.title}</h3>
          </div>
        </div>
        <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
          <span className="flex items-center gap-1"><MapPin className="size-3.5" aria-hidden="true" /> {r.area} · <span className="font-mono">{r.distance}</span></span>
          <span className="flex items-center gap-1"><Users className="size-3.5" aria-hidden="true" /> <span className="font-mono">{r.people}</span> people</span>
          {r.vulnerable && <span className="rounded bg-warn-tint px-1.5 py-0.5 font-medium text-warn">{r.vulnerable}</span>}
          <span className="font-mono">{r.posted}</span>
        </div>
        <div className="mt-auto flex gap-2">
          <button
            type="button"
            onClick={onAccept}
            disabled={accepted}
            className={cn(
              'flex h-10 flex-1 items-center justify-center gap-1.5 rounded-lg text-sm font-semibold transition',
              accepted ? 'bg-teal-tint text-teal' : 'bg-teal text-white hover:brightness-110',
            )}
          >
            {accepted ? (<><Check className="size-4" aria-hidden="true" /> You are helping</>) : 'I can help'}
          </button>
          <button type="button" className="h-10 rounded-lg border px-4 text-sm font-medium hover:bg-secondary">Details</button>
        </div>
      </Card>
    </li>
  )
}
