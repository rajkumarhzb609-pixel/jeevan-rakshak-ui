'use client'

import dynamic from 'next/dynamic'
import { useState } from 'react'
import { BadgeCheck, Navigation, Phone, Search, Share2 } from 'lucide-react'
import { places, type PlaceType } from '@/lib/data'
import { cn } from '@/lib/utils'
import { StatusPill } from '@/components/jr/ui'

const LeafletMap = dynamic(() => import('./leaflet-map'), {
  ssr: false,
  loading: () => <div className="size-full animate-pulse bg-secondary" />,
})

const filters: { id: 'all' | PlaceType; label: string; color: string }[] = [
  { id: 'all', label: 'All', color: 'bg-navy' },
  { id: 'shelter', label: 'Shelters', color: 'bg-safe' },
  { id: 'hospital', label: 'Hospitals', color: 'bg-navy' },
  { id: 'relief', label: 'Relief centres', color: 'bg-teal' },
  { id: 'emergency', label: 'Emergency', color: 'bg-danger' },
]

const legend = [
  { label: 'You', cls: 'bg-info rounded-full' },
  { label: 'Safe zone', cls: 'bg-safe/30 border border-dashed border-safe rounded-full' },
  { label: 'Danger zone', cls: 'bg-danger/20 border border-dashed border-danger' },
  { label: 'Route', cls: 'h-1 bg-teal rounded-full' },
]

export function SafetyMap() {
  const [filter, setFilter] = useState<'all' | PlaceType>('all')
  const [selectedId, setSelectedId] = useState<string | null>('p1')
  const visible = places.filter((p) => filter === 'all' || p.type === filter)

  return (
    <div className="relative -mx-4 -mt-6 h-[calc(100dvh-4rem-5rem)] overflow-hidden md:-mx-6 lg:-mx-8 lg:h-[calc(100dvh-4rem)] lg:-mb-10">
      <div className="absolute inset-0 z-0">
        <LeafletMap places={visible} selectedId={selectedId} onSelect={setSelectedId} />
      </div>

      <div className="pointer-events-none absolute inset-x-0 top-0 z-[500] flex flex-col gap-2 p-3 md:p-4 lg:left-[392px]">
        <label className="pointer-events-auto relative max-w-md lg:hidden">
          <span className="sr-only">Search location</span>
          <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
          <input
            type="search"
            placeholder="Search location…"
            className="h-11 w-full rounded-xl border bg-card/95 pr-3 pl-9 text-sm shadow-lg outline-none backdrop-blur-md focus-visible:ring-2 focus-visible:ring-ring"
          />
        </label>
        <div className="no-scrollbar pointer-events-auto flex gap-2 overflow-x-auto">
          {filters.map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => setFilter(f.id)}
              aria-pressed={filter === f.id}
              className={cn(
                'inline-flex shrink-0 items-center gap-2 rounded-full border px-3.5 py-2 text-sm font-medium shadow-md backdrop-blur-md transition',
                filter === f.id ? 'border-navy bg-navy text-white' : 'bg-card/95 text-navy hover:bg-card',
              )}
            >
              <span className={cn('size-2 rounded-full', filter === f.id ? 'bg-white' : f.color)} aria-hidden="true" />
              {f.label}
            </button>
          ))}
        </div>
      </div>

      <aside
        aria-label="Nearby safe places"
        className="absolute inset-x-0 bottom-0 z-[500] flex max-h-[48%] flex-col rounded-t-3xl border-t bg-card/95 shadow-2xl backdrop-blur-xl lg:inset-y-4 lg:right-auto lg:bottom-4 lg:left-4 lg:max-h-none lg:w-[360px] lg:rounded-2xl lg:border"
      >
        <div className="mx-auto mt-2 h-1 w-10 rounded-full bg-border lg:hidden" aria-hidden="true" />
        <div className="flex items-center justify-between px-5 pt-4 pb-3">
          <div>
            <p className="text-[11px] font-semibold tracking-[0.14em] text-muted-foreground uppercase">Nearby safe places</p>
            <p className="text-sm text-muted-foreground">Within 5 km of you</p>
          </div>
          <span className="rounded-full bg-teal-tint px-2.5 py-1 font-mono text-xs font-semibold text-teal">{visible.length}</span>
        </div>
        <ul className="flex-1 overflow-y-auto px-3 pb-3">
          {visible.map((p) => {
            const active = p.id === selectedId
            const pct = p.capacity ? Math.round((p.capacity.used / p.capacity.total) * 100) : 0
            return (
              <li key={p.id}>
                <button
                  type="button"
                  onClick={() => setSelectedId(p.id)}
                  className={cn(
                    'w-full rounded-xl p-3 text-left transition',
                    active ? 'bg-teal-tint ring-1 ring-teal/30' : 'hover:bg-secondary',
                  )}
                >
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-sm font-semibold text-navy">{p.name}</p>
                    <StatusPill tone={p.status === 'Open' ? 'safe' : 'warn'} className="shrink-0 text-[10px]">
                      {p.status}
                    </StatusPill>
                  </div>
                  <p className="mt-0.5 font-mono text-xs text-muted-foreground">{p.distance} · {p.eta}</p>
                  {active && (
                    <div className="mt-3 flex flex-col gap-3">
                      <div className="flex flex-wrap gap-1.5">
                        {p.facilities.map((f) => (
                          <span key={f} className="rounded-md bg-card px-2 py-0.5 text-[11px] font-medium text-navy ring-1 ring-border">
                            {f}
                          </span>
                        ))}
                      </div>
                      {p.capacity && (
                        <div>
                          <div className="flex justify-between text-xs">
                            <span className="text-muted-foreground">Capacity</span>
                            <span className="font-mono font-medium">{p.capacity.used} / {p.capacity.total}</span>
                          </div>
                          <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-card">
                            <div className={cn('h-full rounded-full', pct > 85 ? 'bg-warn' : 'bg-safe')} style={{ width: `${pct}%` }} />
                          </div>
                        </div>
                      )}
                      <p className="flex items-center gap-1 text-[11px] text-muted-foreground">
                        <BadgeCheck className="size-3.5 text-info" aria-hidden="true" /> Verified {p.verified}
                      </p>
                    </div>
                  )}
                </button>
                {active && (
                  <div className="flex gap-2 px-3 pt-1 pb-3">
                    <span className="flex h-9 flex-1 items-center justify-center gap-1.5 rounded-lg bg-teal text-sm font-semibold text-white">
                      <Navigation className="size-4" aria-hidden="true" /> Navigate
                    </span>
                    <span className="flex size-9 items-center justify-center rounded-lg border bg-card" aria-label="Call">
                      <Phone className="size-4" aria-hidden="true" />
                    </span>
                    <span className="flex size-9 items-center justify-center rounded-lg border bg-card" aria-label="Share">
                      <Share2 className="size-4" aria-hidden="true" />
                    </span>
                  </div>
                )}
              </li>
            )
          })}
        </ul>
      </aside>

      <div className="absolute right-14 bottom-6 z-[500] hidden rounded-xl border bg-card/95 p-3 shadow-lg backdrop-blur-md lg:block">
        <p className="text-[10px] font-semibold tracking-wider text-muted-foreground uppercase">Legend</p>
        <ul className="mt-2 flex flex-col gap-1.5">
          {legend.map((l) => (
            <li key={l.label} className="flex items-center gap-2 text-xs">
              <span className={cn('inline-block size-3', l.cls)} aria-hidden="true" />
              {l.label}
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
