'use client'

import { useState } from 'react'
import Image from 'next/image'
import { BadgeCheck, Heart, Lock, Package, Users } from 'lucide-react'
import { inr, ngos } from '@/lib/data'
import { cn } from '@/lib/utils'
import { Card, Eyebrow, PageHeader } from '@/components/jr/ui'

const amounts = [500, 1000, 2500, 5000]

export function Support() {
  const [ngoId, setNgoId] = useState(ngos[0].id)
  const [amount, setAmount] = useState(1000)
  const [monthly, setMonthly] = useState(false)
  const ngo = ngos.find((n) => n.id === ngoId)!

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6">
      <PageHeader title="NGOs & donations" description="Support verified organisations responding on the ground." />

      <div className="relative overflow-hidden rounded-2xl bg-navy text-white">
        <Image src="/images/volunteers.png" alt="" fill sizes="100vw" className="object-cover opacity-30" />
        <div className="relative grid gap-6 p-6 md:grid-cols-3 md:p-8">
          <div className="md:col-span-2">
            <p className="text-[11px] font-semibold tracking-[0.14em] text-[#2cc4b0] uppercase">Monsoon relief 2026</p>
            <h2 className="mt-2 text-2xl font-semibold text-balance md:text-3xl">Every kit reaches a family within 24 hours.</h2>
          </div>
          <dl className="grid grid-cols-3 gap-4 self-end md:grid-cols-1">
            {[
              [Package, '14,820', 'Relief kits delivered'],
              [Users, '5,604', 'Donors this season'],
            ].map(([Icon, v, l]) => {
              const I = Icon as typeof Package
              return (
                <div key={l as string} className="flex items-center gap-3">
                  <I className="size-5 text-[#2cc4b0]" aria-hidden="true" />
                  <div>
                    <dd className="font-mono text-lg font-semibold">{v as string}</dd>
                    <dt className="text-xs text-white/70">{l as string}</dt>
                  </div>
                </div>
              )
            })}
          </dl>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_380px]">
        <ul className="flex flex-col gap-3">
          {ngos.map((n) => {
            const pct = Math.round((n.raised / n.goal) * 100)
            const active = n.id === ngoId
            return (
              <li key={n.id}>
                <button
                  type="button"
                  onClick={() => setNgoId(n.id)}
                  aria-pressed={active}
                  className={cn(
                    'w-full rounded-2xl border bg-card p-5 text-left transition',
                    active ? 'border-teal ring-2 ring-teal/20' : 'hover:border-navy/20',
                  )}
                >
                  <div className="flex items-start gap-4">
                    <span className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-teal-tint text-sm font-semibold text-teal">
                      {n.name.split(' ').map((w) => w[0]).slice(0, 2).join('')}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="flex items-center gap-1.5 font-semibold">
                        {n.name}
                        {n.verified && <BadgeCheck className="size-4 text-info" aria-label="Verified" />}
                      </p>
                      <p className="text-sm text-muted-foreground">{n.focus} · {n.region}</p>
                      <div className="mt-4 h-2 overflow-hidden rounded-full bg-secondary">
                        <div className="h-full rounded-full bg-teal transition-all" style={{ width: `${pct}%` }} />
                      </div>
                      <div className="mt-2 flex justify-between font-mono text-xs text-muted-foreground">
                        <span><span className="font-semibold text-navy">{inr(n.raised)}</span> of {inr(n.goal)}</span>
                        <span>{n.donors.toLocaleString('en-IN')} donors</span>
                      </div>
                    </div>
                  </div>
                </button>
              </li>
            )
          })}
        </ul>

        <Card className="h-fit p-6 lg:sticky lg:top-24">
          <Eyebrow>Donate to</Eyebrow>
          <p className="mt-1 flex items-center gap-1.5 font-semibold">{ngo.name} <BadgeCheck className="size-4 text-info" aria-hidden="true" /></p>

          <div className="mt-5 grid grid-cols-2 gap-1 rounded-lg bg-secondary p-1 text-sm font-semibold">
            {['One-time', 'Monthly'].map((l, i) => (
              <button
                key={l}
                type="button"
                aria-pressed={monthly === (i === 1)}
                onClick={() => setMonthly(i === 1)}
                className={cn('rounded-md py-2 transition', monthly === (i === 1) ? 'bg-card shadow-sm' : 'text-muted-foreground')}
              >
                {l}
              </button>
            ))}
          </div>

          <div className="mt-4 grid grid-cols-2 gap-2">
            {amounts.map((a) => (
              <button
                key={a}
                type="button"
                aria-pressed={amount === a}
                onClick={() => setAmount(a)}
                className={cn(
                  'h-12 rounded-lg border font-mono text-sm font-semibold transition',
                  amount === a ? 'border-teal bg-teal-tint text-teal' : 'hover:bg-secondary',
                )}
              >
                {inr(a)}
              </button>
            ))}
          </div>
          <p className="mt-4 rounded-lg bg-safe-tint px-3 py-2 text-xs text-safe">
            {inr(amount)} provides about {Math.max(1, Math.floor(amount / 500))} family relief kit{amount >= 1000 ? 's' : ''}.
          </p>
          <button type="button" className="mt-5 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-navy text-[15px] font-semibold text-white hover:bg-navy-soft">
            <Heart className="size-4" aria-hidden="true" /> Donate {inr(amount)}{monthly ? ' / month' : ''}
          </button>
          <p className="mt-3 flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
            <Lock className="size-3" aria-hidden="true" /> Secure payment · 80G tax receipt
          </p>
        </Card>
      </div>
    </div>
  )
}
