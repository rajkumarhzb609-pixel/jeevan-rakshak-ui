'use client'

import 'leaflet/dist/leaflet.css'
import { useEffect } from 'react'
import L from 'leaflet'
import { Circle, MapContainer, Marker, Polygon, Polyline, TileLayer, useMap, ZoomControl } from 'react-leaflet'
import { dangerZones, safeZones, userPosition, type Place, type PlaceType } from '@/lib/data'

const pinColor: Record<PlaceType, string> = {
  shelter: '#16a34a',
  hospital: '#0b1f3a',
  relief: '#0e9f8e',
  emergency: '#dc2626',
}

const glyph: Record<PlaceType, string> = {
  shelter: '<path d="M3 10.5 12 3l9 7.5V21H3z" fill="none" stroke="white" stroke-width="2.2" stroke-linejoin="round"/>',
  hospital: '<path d="M12 5v14M5 12h14" stroke="white" stroke-width="3" stroke-linecap="round"/>',
  relief: '<path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.5-7 10-7 10z" fill="white"/>',
  emergency: '<path d="M12 3v3M5 7l2 2M19 7l-2 2M6 20h12M8 20v-6a4 4 0 0 1 8 0v6" fill="none" stroke="white" stroke-width="2.2" stroke-linecap="round"/>',
}

function pinIcon(type: PlaceType, active: boolean) {
  const size = active ? 46 : 36
  return L.divIcon({
    className: '',
    iconSize: [size, size],
    iconAnchor: [size / 2, size],
    html: `<div style="width:${size}px;height:${size}px;transition:all .2s;filter:drop-shadow(0 4px 8px rgba(11,31,58,.3))">
      <svg viewBox="0 0 36 36" width="${size}" height="${size}"><path d="M18 35s12-11.2 12-20A12 12 0 0 0 6 15c0 8.8 12 20 12 20z" fill="${pinColor[type]}" stroke="white" stroke-width="2"/>
      <g transform="translate(10.8 7.5) scale(.6)">${glyph[type]}</g></svg></div>`,
  })
}

const youIcon = L.divIcon({
  className: '',
  iconSize: [22, 22],
  iconAnchor: [11, 11],
  html: `<span style="position:relative;display:block;width:22px;height:22px">
    <span class="animate-pulse-ring" style="position:absolute;inset:0;border-radius:9999px;background:#2563eb"></span>
    <span style="position:absolute;inset:0;border-radius:9999px;background:#2563eb;border:3px solid white;box-shadow:0 2px 8px rgba(37,99,235,.5)"></span></span>`,
})

function FlyTo({ target }: { target: [number, number] | null }) {
  const map = useMap()
  useEffect(() => {
    if (target) map.flyTo(target, 15, { duration: 0.8 })
  }, [target, map])
  return null
}

export default function LeafletMap({
  places,
  selectedId,
  onSelect,
}: {
  places: Place[]
  selectedId: string | null
  onSelect: (id: string) => void
}) {
  const selected = places.find((p) => p.id === selectedId) ?? null

  return (
    <MapContainer center={userPosition} zoom={14} zoomControl={false} className="size-full" attributionControl>
      <TileLayer
          url="https://tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          className="jr-tiles"
      />
      <ZoomControl position="bottomright" />
      {dangerZones.map((poly, i) => (
        <Polygon
          key={i}
          positions={poly}
          pathOptions={{ color: '#dc2626', weight: 1.5, fillColor: '#dc2626', fillOpacity: 0.14, dashArray: '4 4' }}
        />
      ))}
      {safeZones.map((z, i) => (
        <Circle
          key={i}
          center={z.center}
          radius={z.radius}
          pathOptions={{ color: '#16a34a', weight: 1.5, fillColor: '#16a34a', fillOpacity: 0.12, dashArray: '6 6' }}
        />
      ))}
      {selected && (
        <Polyline
          positions={[userPosition, selected.position]}
          pathOptions={{ color: '#0e9f8e', weight: 4, dashArray: '8 8', className: 'animate-dash' }}
        />
      )}
      <Marker position={userPosition} icon={youIcon} />
      {places.map((p) => (
        <Marker
          key={p.id}
          position={p.position}
          icon={pinIcon(p.type, p.id === selectedId)}
          eventHandlers={{ click: () => onSelect(p.id) }}
          zIndexOffset={p.id === selectedId ? 1000 : 0}
        />
      ))}
      <FlyTo target={selected?.position ?? null} />
    </MapContainer>
  )
}
