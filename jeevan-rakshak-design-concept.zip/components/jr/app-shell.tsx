'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  Bell,
  Bot,
  HandHeart,
  HeartHandshake,
  Home,
  LifeBuoy,
  Map,
  Search,
  Siren,
  TriangleAlert,
  UserRound,
  Globe,
} from 'lucide-react'
import { Logo, LogoMark } from '@/components/brand/logo'
import { cn } from '@/lib/utils'

const nav = [
  { href: '/dashboard', label: 'Dashboard', icon: Home },
  { href: '/map', label: 'Safety Map', icon: Map },
  { href: '/alerts', label: 'Alerts', icon: TriangleAlert, badge: 2 },
  { href: '/assistant', label: 'Jeevan AI', icon: Bot },
  { href: '/request-help', label: 'Request Help', icon: LifeBuoy },
  { href: '/help-others', label: 'Help Others', icon: HandHeart },
  { href: '/support', label: 'NGOs & Donate', icon: HeartHandshake },
  { href: '/profile', label: 'Profile', icon: UserRound },
]

const mobileNav = [
  { href: '/dashboard', label: 'Home', icon: Home },
  { href: '/map', label: 'Map', icon: Map },
  { href: '/sos', label: 'SOS', icon: Siren },
  { href: '/alerts', label: 'Alerts', icon: TriangleAlert },
  { href: '/assistant', label: 'AI', icon: Bot },
]

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const isActive = (href: string) => pathname === href || pathname.startsWith(href + '/')

  return (
    <div className="min-h-dvh bg-background">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col bg-sidebar text-sidebar-foreground lg:flex">
        <div className="flex h-16 items-center px-5">
          <Link href="/" aria-label="Jeevan Rakshak home">
            <Logo tone="light" />
          </Link>
        </div>

        <nav aria-label="Main" className="flex-1 overflow-y-auto px-3 py-4">
          <ul className="flex flex-col gap-0.5">
            {nav.map((item) => {
              const active = isActive(item.href)
              return (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    aria-current={active ? 'page' : undefined}
                    className={cn(
                      'group relative flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors',
                      active
                        ? 'bg-sidebar-accent text-white'
                        : 'text-sidebar-foreground/80 hover:bg-sidebar-accent/60 hover:text-white',
                    )}
                  >
                    {active && (
                      <span className="absolute inset-y-2 left-0 w-[3px] rounded-r bg-teal" aria-hidden="true" />
                    )}
                    <item.icon className="size-[18px]" aria-hidden="true" />
                    <span className="flex-1">{item.label}</span>
                    {item.badge && (
                      <span className="rounded-full bg-danger px-1.5 py-0.5 font-mono text-[10px] font-semibold text-white">
                        {item.badge}
                      </span>
                    )}
                  </Link>
                </li>
              )
            })}
          </ul>
        </nav>

        <div className="flex flex-col gap-3 p-4">
          <div className="rounded-xl border border-sidebar-border bg-sidebar-accent/50 p-3">
            <div className="flex items-center gap-2">
              <span className="relative flex size-2.5">
                <span className="absolute inset-0 animate-pulse-ring rounded-full bg-safe" aria-hidden="true" />
                <span className="relative size-2.5 rounded-full bg-safe" />
              </span>
              <span className="text-xs font-semibold tracking-wider text-white uppercase">You are safe</span>
            </div>
            <p className="mt-1 text-xs text-sidebar-foreground/70">Kothrud, Pune · Updated 2m ago</p>
          </div>
          <Link
            href="/sos"
            className="flex items-center justify-center gap-2 rounded-xl bg-danger py-3 text-sm font-semibold tracking-wide text-white shadow-lg shadow-danger/30 transition hover:brightness-110"
          >
            <Siren className="size-4" aria-hidden="true" />
            SOS EMERGENCY
          </Link>
        </div>
      </aside>

      <div className="lg:pl-64">
        <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b bg-background/85 px-4 backdrop-blur-md md:px-6">
          <Link href="/" className="lg:hidden" aria-label="Jeevan Rakshak home">
            <LogoMark className="text-navy" />
          </Link>
          <label className="relative hidden max-w-md flex-1 md:block">
            <span className="sr-only">Search places and alerts</span>
            <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <input
              type="search"
              placeholder="Search places, shelters, alerts…"
              className="h-10 w-full rounded-lg border bg-card pr-3 pl-9 text-sm outline-none placeholder:text-muted-foreground focus-visible:ring-2 focus-visible:ring-ring"
            />
          </label>
          <div className="ml-auto flex items-center gap-1.5">
            <button
              type="button"
              className="hidden h-9 items-center gap-1.5 rounded-lg px-2.5 text-sm font-medium text-muted-foreground hover:bg-secondary sm:flex"
            >
              <Globe className="size-4" aria-hidden="true" />
              EN
            </button>
            <Link
              href="/alerts"
              className="relative flex size-9 items-center justify-center rounded-lg text-muted-foreground hover:bg-secondary"
              aria-label="Notifications, 2 critical"
            >
              <Bell className="size-[18px]" aria-hidden="true" />
              <span className="absolute top-2 right-2 size-2 rounded-full bg-danger ring-2 ring-background" />
            </Link>
            <Link
              href="/profile"
              className="ml-1 flex size-9 items-center justify-center rounded-full bg-navy text-xs font-semibold text-white"
              aria-label="Your profile"
            >
              AS
            </Link>
          </div>
        </header>

        <main className="px-4 pt-6 pb-28 md:px-6 lg:px-8 lg:pb-10">{children}</main>
      </div>

      <nav
        aria-label="Mobile"
        className="fixed inset-x-0 bottom-0 z-40 border-t bg-card/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md lg:hidden"
      >
        <ul className="grid grid-cols-5">
          {mobileNav.map((item) => {
            const active = isActive(item.href)
            if (item.href === '/sos') {
              return (
                <li key={item.href} className="flex justify-center">
                  <Link
                    href="/sos"
                    aria-label="SOS emergency"
                    className="-mt-6 flex size-16 flex-col items-center justify-center rounded-full bg-danger text-white shadow-xl shadow-danger/40 ring-4 ring-background"
                  >
                    <Siren className="size-6" aria-hidden="true" />
                    <span className="text-[10px] font-bold tracking-wider">SOS</span>
                  </Link>
                </li>
              )
            }
            return (
              <li key={item.href}>
                <Link
                  href={item.href}
                  aria-current={active ? 'page' : undefined}
                  className={cn(
                    'flex flex-col items-center gap-1 py-2.5 text-[11px] font-medium',
                    active ? 'text-teal' : 'text-muted-foreground',
                  )}
                >
                  <item.icon className="size-5" aria-hidden="true" />
                  {item.label}
                </Link>
              </li>
            )
          })}
        </ul>
      </nav>
    </div>
  )
}
