'use client'

import { useEffect, useRef, useState } from 'react'
import { Check, LocateFixed, Phone, Radio, Siren, UserRound, X } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Card, Eyebrow } from '@/components/jr/ui'

const contacts = [
  { name: 'Priya Sharma', rel: 'Spouse' },
  { name: 'Rakesh Sharma', rel: 'Father' },
  { name: 'Dr. Mehta', rel: 'Family doctor' },
]

const helplines = [
  ['112', 'Emergency'],
  ['1078', 'NDMA'],
  ['108', 'Ambulance'],
  ['101', 'Fire'],
]

type Phase = 'idle' | 'countdown' | 'active'

export function Sos() {
  const [phase, setPhase] = useState<Phase>('idle')
  const [count, setCount] = useState(5)
  const timer = useRef<ReturnType<typeof setInterval> | null>(null)

  useEffect(() => () => { if (timer.current) clearInterval(timer.current) }, [])

  function start() {
    setPhase('countdown')
    setCount(5)
    timer.current = setInterval(() => {
      setCount((c) => {
        if (c <= 1) {
          if (timer.current) clearInterval(timer.current)
          setPhase('active')
          return 0
        }
        return c - 1
      })
    }, 1000)
  }

  function cancel() {
    if (timer.current) clearInterval(timer.current)
    setPhase('idle')
  }

  return (
    <div className="mx-auto flex max-w-4xl flex-col gap-6">
      <section
        className={cn(
          'relative flex flex-col items-center overflow-hidden rounded-3xl px-6 py-12 text-center transition-colors md:py-16',
          phase === 'idle' ? 'bg-card border' : 'bg-danger text-white',
        )}
      >
        {phase === 'idle' && (
          <>
            <Eyebrow className="text-danger">Emergency SOS</Eyebrow>
            <h1 className="mt-2 text-2xl font-semibold text-balance md:text-3xl">Press and we alert responders instantly</h1>
            <p className="mt-2 max-w-md text-sm text-muted-foreground">
              Your live location is shared with the nearest emergency services and your emergency contacts.
            </p>
          </>
        )}
        {phase === 'countdown' && (
          <>
            <p className="text-[11px] font-semibold tracking-[0.14em] uppercase opacity-80">Sending SOS in</p>
            <p className="mt-1 font-mono text-5xl font-semibold" aria-live="assertive">{count}</p>
          </>
        )}
        {phase === 'active' && (
          <>
            <p className="inline-flex items-center gap-2 text-[11px] font-semibold tracking-[0.14em] uppercase">
              <Radio className="size-4" aria-hidden="true" /> SOS active · Broadcasting
            </p>
            <h1 className="mt-2 text-2xl font-semibold md:text-3xl" aria-live="assertive">Help has been alerted</h1>
            <p className="mt-2 text-sm text-white/80">Nearest unit: Erandwane Fire & Rescue · ETA 9 min</p>
          </>
        )}

        <div className="relative mt-10 flex size-56 items-center justify-center md:size-64">
          {phase !== 'idle' && (
            <>
              <span className="absolute inset-0 animate-pulse-ring rounded-full bg-white/30" aria-hidden="true" />
              <span className="absolute inset-0 animate-pulse-ring rounded-full bg-white/20 [animation-delay:1s]" aria-hidden="true" />
            </>
          )}
          {phase === 'idle' && (
            <span className="absolute inset-0 animate-pulse-ring rounded-full bg-danger/25" aria-hidden="true" />
          )}
          <button
            type="button"
            onClick={phase === 'idle' ? start : undefined}
            disabled={phase !== 'idle'}
            aria-label="Send SOS emergency alert"
            className={cn(
              'relative flex size-full flex-col items-center justify-center gap-2 rounded-full font-bold tracking-widest shadow-2xl transition active:scale-95',
              phase === 'idle'
                ? 'bg-danger text-white shadow-danger/40 ring-8 ring-danger/15 hover:brightness-110'
                : 'bg-white text-danger ring-8 ring-white/20',
            )}
          >
            {phase === 'active' ? <Check className="size-14" aria-hidden="true" /> : <Siren className="size-14" aria-hidden="true" />}
            <span className="text-3xl">SOS</span>
            {phase === 'idle' && <span className="text-[11px] font-medium tracking-wider opacity-80">TAP TO SEND</span>}
          </button>
        </div>

        {phase !== 'idle' && (
          <button
            type="button"
            onClick={cancel}
            className="mt-10 inline-flex h-11 items-center gap-2 rounded-xl bg-white/15 px-5 text-sm font-semibold ring-1 ring-white/30 hover:bg-white/25"
          >
            <X className="size-4" aria-hidden="true" /> {phase === 'active' ? 'I am safe now — stop SOS' : 'Cancel'}
          </button>
        )}

        <p className={cn('mt-8 flex items-center gap-1.5 text-xs', phase === 'idle' ? 'text-muted-foreground' : 'text-white/80')}>
          <LocateFixed className="size-3.5" aria-hidden="true" />
          <span className="font-mono">18.5074°N, 73.8077°E · ±8 m</span>
        </p>
      </section>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="p-5">
          <Eyebrow>Quick dial</Eyebrow>
          <div className="mt-3 grid grid-cols-2 gap-2">
            {helplines.map(([n, l]) => (
              <a key={n} href={`tel:${n}`} className="flex items-center gap-3 rounded-xl border p-3 transition hover:border-danger/30 hover:bg-danger-tint">
                <Phone className="size-4 text-danger" aria-hidden="true" />
                <span>
                  <span className="block font-mono text-lg font-semibold leading-none">{n}</span>
                  <span className="text-xs text-muted-foreground">{l}</span>
                </span>
              </a>
            ))}
          </div>
        </Card>
        <Card className="p-5">
          <Eyebrow>Emergency contacts notified</Eyebrow>
          <ul className="mt-3 divide-y">
            {contacts.map((c) => (
              <li key={c.name} className="flex items-center gap-3 py-2.5">
                <span className="flex size-9 items-center justify-center rounded-full bg-secondary"><UserRound className="size-4" aria-hidden="true" /></span>
                <span className="flex-1">
                  <span className="block text-sm font-medium">{c.name}</span>
                  <span className="text-xs text-muted-foreground">{c.rel}</span>
                </span>
                <span className={cn('text-xs font-semibold', phase === 'active' ? 'text-safe' : 'text-muted-foreground')}>
                  {phase === 'active' ? 'Notified' : 'Ready'}
                </span>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </div>
  )
}
