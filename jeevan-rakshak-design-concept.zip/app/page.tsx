import { Hero } from '@/components/landing/hero'
import { Footer, HowItWorks, LandingNav, NgoBand, PlatformBento, TrustBar } from '@/components/landing/sections'

export default function LandingPage() {
  return (
    <>
      <LandingNav />
      <main>
        <Hero />
        <TrustBar />
        <HowItWorks />
        <PlatformBento />
        <NgoBand />
      </main>
      <Footer />
    </>
  )
}
