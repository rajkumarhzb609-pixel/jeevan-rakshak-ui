import Link from 'next/link'
import {
  ArrowRight,
  Bot,
  Building2,
  CheckCircle2,
  Circle,
  HandHeart,
  LifeBuoy,
  MapPin,
  RefreshCw,
  ShieldCheck,
  Siren,
  TriangleAlert,
  Waves,
} from 'lucide-react'
import { alerts, places } from '@/lib/data'
import { Card, Eyebrow, IconBadge, StatusPill } from '@/components/jr/ui'

const quickActions = [
  { href: '/sos', title: 'Emergency help', hint: 'One-tap SOS to responders', icon: Siren, tone: 'danger' as const },
  { href: '/map', title: 'Safe places', hint: '6 shelters within 5 km', icon: MapPin, tone: 'safe' as const },
  { href: '/alerts', title: 'Disaster alerts', hint: '2 active near you', icon: TriangleAlert, tone: 'warn' as const },
  { href: '/assistant', title: 'Ask Jeevan AI', hint: 'Personalised guidance', icon: Bot, tone: 'teal' as const },
  { href: '/request-help', title: 'Request help', hint: 'Rescue, food, medical', icon: LifeBuoy, tone: 'info' as const },
  { href: '/help-others', title: 'Help others', hint: '5 requests nearby', icon: HandHeart, tone: 'teal' as const },
]

const checklist = [
  { label: 'Emergency contacts added', done: true },
  { label: 'Go-bag packed (water, torch, meds)', done: true },
  { label: 'Documents in waterproof pouch', done: true },
  { label: 'Family meeting point decided', done: true },
  { label: 'Power bank charged', done: false },
  { label: 'First-aid kit checked', done: false },
  { label: 'Offline map downloaded', done: false },
]

export default function DashboardPage() {
  const nearAlert = alerts[1]
  const done = checklist.filter((c) => c.done).length

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6">
      <div className="flex flex-col justify-between gap-2 sm:flex-row sm:items-end">
        <div>
          <p className="text-sm text-muted-foreground">Good evening,</p>
          <h1 className="text-2xl font-semibold tracking-tight md:text-3xl">Aarav Sharma</h1>
        </div>
        <p className="flex items-center gap-1.5 font-mono text-xs text-muted-foreground">
          <RefreshCw className="size-3.5" aria-hidden="true" /> Updated 14:32 IST
        </p>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1.4fr_1fr]">
        <Card className="relative overflow-hidden border-safe/25 bg-safe-tint p-6 md:p-7">
          <div className="absolute inset-y-0 left-0 w-1 bg-safe" aria-hidden="true" />
          <div className="flex flex-col gap-6 sm:flex-row sm:items-center">
            <div className="relative flex size-20 shrink-0 items-center justify-center">
              <span className="absolute inset-0 animate-pulse-ring rounded-full bg-safe/30" aria-hidden="true" />
              <span className="relative flex size-20 items-center justify-center rounded-full bg-safe text-white shadow-lg shadow-safe/30">
                <ShieldCheck className="size-10" aria-hidden="true" />
              </span>
            </div>
            <div className="flex-1">
              <Eyebrow className="text-safe">Your safety status</Eyebrow>
              <p className="mt-1 text-3xl font-semibold tracking-tight text-navy">You are safe</p>
              <p className="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
                <MapPin className="size-3.5" aria-hidden="true" />
                Kothrud, Pune · <span className="font-mono">18.50°N 73.80°E</span>
              </p>
              <div className="mt-4 flex items-center gap-3">
                <span className="text-xs font-medium text-muted-foreground">Nearby risk</span>
                <div className="flex gap-1" aria-label="Risk level 2 of 5, low">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <span key={i} className={`h-2 w-6 rounded-full ${i <= 2 ? 'bg-safe' : 'bg-safe/15'}`} />
                  ))}
                </div>
                <StatusPill tone="safe" dot={false}>Low</StatusPill>
              </div>
            </div>
          </div>
        </Card>

        <Card className="relative overflow-hidden p-6">
          <div className="absolute inset-y-0 left-0 w-1 bg-warn" aria-hidden="true" />
          <div className="flex items-start justify-between gap-3">
            <IconBadge icon={Waves} tone="warn" />
            <StatusPill tone="warn">High · New</StatusPill>
          </div>
          <p className="mt-4 text-[11px] font-semibold tracking-wider text-warn uppercase">Active alert near you</p>
          <h2 className="mt-1 font-semibold text-navy text-pretty">{nearAlert.title}</h2>
          <p className="mt-1 font-mono text-xs text-muted-foreground">
            Issued {nearAlert.issued} · {nearAlert.distance} away · Source: {nearAlert.source}
          </p>
          <Link
            href="/alerts"
            className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-navy hover:text-teal"
          >
            View alert <ArrowRight className="size-4" aria-hidden="true" />
          </Link>
        </Card>
      </div>

      <section aria-labelledby="qa">
        <Eyebrow>
          <span id="qa">Quick actions</span>
        </Eyebrow>
        <div className="mt-3 grid grid-cols-2 gap-3 md:grid-cols-3">
          {quickActions.map((a) => (
            <Link
              key={a.href}
              href={a.href}
              className="group flex flex-col gap-4 rounded-2xl border bg-card p-4 transition hover:-translate-y-0.5 hover:border-teal/40 hover:shadow-md md:p-5"
            >
              <div className="flex items-center justify-between">
                <IconBadge icon={a.icon} tone={a.tone} />
                <ArrowRight className="size-4 text-muted-foreground opacity-0 transition group-hover:opacity-100" aria-hidden="true" />
              </div>
              <div>
                <p className="font-semibold text-navy">{a.title}</p>
                <p className="mt-0.5 text-xs text-muted-foreground md:text-sm">{a.hint}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="p-5">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold">Nearest safe places</h2>
            <Link href="/map" className="text-sm font-medium text-teal hover:underline">Open map</Link>
          </div>
          <ul className="mt-3 divide-y">
            {places.slice(0, 3).map((p) => (
              <li key={p.id} className="flex items-center gap-3 py-3">
                <IconBadge icon={p.type === 'hospital' ? Building2 : ShieldCheck} tone={p.type === 'hospital' ? 'info' : 'safe'} size="sm" />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{p.name}</p>
                  <p className="font-mono text-xs text-muted-foreground">{p.distance} · {p.eta}</p>
                </div>
                <StatusPill tone="safe">{p.status}</StatusPill>
              </li>
            ))}
          </ul>
        </Card>

        <Card className="p-5">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold">Preparedness checklist</h2>
            <span className="font-mono text-sm text-muted-foreground">{done}/{checklist.length}</span>
          </div>
          <div className="mt-3 h-2 overflow-hidden rounded-full bg-secondary">
            <div className="h-full rounded-full bg-teal" style={{ width: `${(done / checklist.length) * 100}%` }} />
          </div>
          <ul className="mt-4 grid gap-2.5 sm:grid-cols-2">
            {checklist.map((c) => (
              <li key={c.label} className="flex items-start gap-2 text-sm">
                {c.done ? (
                  <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-teal" aria-hidden="true" />
                ) : (
                  <Circle className="mt-0.5 size-4 shrink-0 text-muted-foreground/50" aria-hidden="true" />
                )}
                <span className={c.done ? 'text-muted-foreground line-through decoration-muted-foreground/40' : ''}>
                  {c.label}
                </span>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </div>
  )
}
