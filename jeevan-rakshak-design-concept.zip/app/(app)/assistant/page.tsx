import { Assistant } from '@/components/jr/assistant'

export default function AssistantPage() {
  return <Assistant />
}
