import { AlertsView } from '@/components/jr/alerts-view'

export default function AlertsPage() {
  return <AlertsView />
}
