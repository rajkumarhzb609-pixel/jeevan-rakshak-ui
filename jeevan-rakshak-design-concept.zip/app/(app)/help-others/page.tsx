import { HelpOthers } from '@/components/jr/help-others'

export default function HelpOthersPage() {
  return <HelpOthers />
}
