import { SafetyMap } from '@/components/jr/safety-map'

export default function MapPage() {
  return <SafetyMap />
}
