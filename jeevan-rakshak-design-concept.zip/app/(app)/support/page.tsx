import { Support } from '@/components/jr/support'

export default function SupportPage() {
  return <Support />
}
