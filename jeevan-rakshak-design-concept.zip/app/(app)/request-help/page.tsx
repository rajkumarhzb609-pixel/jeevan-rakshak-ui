import { RequestHelp } from '@/components/jr/request-help'

export default function RequestHelpPage() {
  return <RequestHelp />
}
