import { Sos } from '@/components/jr/sos'

export default function SosPage() {
  return <Sos />
}
