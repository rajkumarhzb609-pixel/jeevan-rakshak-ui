import {
  BadgeCheck,
  Bell,
  Droplet,
  Globe,
  HandHeart,
  HeartPulse,
  LocateFixed,
  MapPin,
  Phone,
  ShieldCheck,
  UserRound,
  WifiOff,
} from 'lucide-react'
import { Card, Eyebrow, IconBadge, StatusPill } from '@/components/jr/ui'

const medical = [
  ['Blood group', 'B+'],
  ['Allergies', 'Penicillin'],
  ['Conditions', 'Asthma (mild)'],
  ['Medication', 'Salbutamol inhaler'],
]

const contacts = [
  { name: 'Priya Sharma', rel: 'Spouse', phone: '+91 98220 41xxx' },
  { name: 'Rakesh Sharma', rel: 'Father', phone: '+91 98500 17xxx' },
  { name: 'Dr. Anil Mehta', rel: 'Family doctor', phone: '+91 20 2543 xxxx' },
]

const prefs = [
  { icon: Bell, label: 'Critical alert sound', desc: 'Override silent mode for critical alerts', on: true },
  { icon: LocateFixed, label: 'Background location', desc: 'Personalised alerts and faster SOS', on: true },
  { icon: WifiOff, label: 'Offline maps', desc: 'Pune region · 84 MB', on: false },
  { icon: Globe, label: 'Language', desc: 'English · हिन्दी · मराठी', on: true },
]

export default function ProfilePage() {
  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-6">
      <Card className="overflow-hidden">
        <div className="h-24 bg-navy bg-[radial-gradient(circle_at_80%_0%,rgb(14_159_142/0.5),transparent_60%)]" />
        <div className="flex flex-col gap-4 px-6 pb-6 sm:flex-row sm:items-end">
          <span className="-mt-10 flex size-20 items-center justify-center rounded-2xl bg-teal text-2xl font-semibold text-white ring-4 ring-card">AS</span>
          <div className="flex-1">
            <h1 className="flex items-center gap-1.5 text-xl font-semibold">Aarav Sharma <BadgeCheck className="size-5 text-info" aria-label="Verified" /></h1>
            <p className="flex items-center gap-1 text-sm text-muted-foreground"><MapPin className="size-3.5" aria-hidden="true" /> Kothrud, Pune · Member since 2024</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <StatusPill tone="safe">Safe</StatusPill>
            <StatusPill tone="teal" dot={false}>Volunteer · Level 2</StatusPill>
          </div>
        </div>
        <dl className="grid grid-cols-3 divide-x border-t">
          {[
            ['12', 'People helped'],
            ['4/7', 'Preparedness'],
            ['₹6,500', 'Donated'],
          ].map(([v, l]) => (
            <div key={l} className="px-4 py-4 text-center">
              <dd className="font-mono text-lg font-semibold">{v}</dd>
              <dt className="text-xs text-muted-foreground">{l}</dt>
            </div>
          ))}
        </dl>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="p-5">
          <div className="flex items-center gap-3">
            <IconBadge icon={HeartPulse} tone="danger" size="sm" />
            <h2 className="font-semibold">Medical information</h2>
          </div>
          <p className="mt-2 text-xs text-muted-foreground">Shared with responders only during an active SOS.</p>
          <dl className="mt-4 grid grid-cols-2 gap-3">
            {medical.map(([k, v]) => (
              <div key={k} className="rounded-xl bg-secondary/60 p-3">
                <dt className="text-[11px] font-semibold tracking-wider text-muted-foreground uppercase">{k}</dt>
                <dd className="mt-1 flex items-center gap-1.5 text-sm font-medium">
                  {k === 'Blood group' && <Droplet className="size-3.5 text-danger" aria-hidden="true" />}
                  {v}
                </dd>
              </div>
            ))}
          </dl>
        </Card>

        <Card className="p-5">
          <div className="flex items-center gap-3">
            <IconBadge icon={UserRound} tone="info" size="sm" />
            <h2 className="flex-1 font-semibold">Emergency contacts</h2>
            <button type="button" className="text-sm font-medium text-teal hover:underline">Add</button>
          </div>
          <ul className="mt-3 divide-y">
            {contacts.map((c) => (
              <li key={c.name} className="flex items-center gap-3 py-3">
                <span className="flex size-9 items-center justify-center rounded-full bg-secondary text-xs font-semibold">
                  {c.name.split(' ').map((w) => w[0]).slice(0, 2).join('')}
                </span>
                <span className="flex-1">
                  <span className="block text-sm font-medium">{c.name}</span>
                  <span className="text-xs text-muted-foreground">{c.rel} · <span className="font-mono">{c.phone}</span></span>
                </span>
                <span className="flex size-8 items-center justify-center rounded-lg border" aria-label={`Call ${c.name}`}>
                  <Phone className="size-3.5" aria-hidden="true" />
                </span>
              </li>
            ))}
          </ul>
        </Card>

        <Card className="p-5 lg:col-span-2">
          <div className="flex items-center gap-3">
            <IconBadge icon={ShieldCheck} tone="teal" size="sm" />
            <h2 className="font-semibold">Safety preferences</h2>
          </div>
          <ul className="mt-4 grid gap-3 md:grid-cols-2">
            {prefs.map((p) => (
              <li key={p.label} className="flex items-center gap-3 rounded-xl border p-4">
                <p.icon className="size-5 text-muted-foreground" aria-hidden="true" />
                <span className="flex-1">
                  <span className="block text-sm font-medium">{p.label}</span>
                  <span className="text-xs text-muted-foreground">{p.desc}</span>
                </span>
                <span
                  role="switch"
                  aria-checked={p.on}
                  aria-label={p.label}
                  className={`relative h-6 w-11 rounded-full transition ${p.on ? 'bg-teal' : 'bg-input'}`}
                >
                  <span className={`absolute top-0.5 size-5 rounded-full bg-white shadow transition-all ${p.on ? 'left-[22px]' : 'left-0.5'}`} />
                </span>
              </li>
            ))}
          </ul>
        </Card>

        <Card className="flex items-center gap-4 border-teal/30 bg-teal-tint p-5 lg:col-span-2">
          <IconBadge icon={HandHeart} tone="teal" />
          <div className="flex-1">
            <Eyebrow className="text-teal">Volunteer skills</Eyebrow>
            <div className="mt-2 flex flex-wrap gap-2">
              {['First aid (certified)', 'Two-wheeler', 'Marathi & Hindi', 'Swimming'].map((s) => (
                <span key={s} className="rounded-full bg-card px-3 py-1 text-xs font-medium ring-1 ring-teal/20">{s}</span>
              ))}
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
