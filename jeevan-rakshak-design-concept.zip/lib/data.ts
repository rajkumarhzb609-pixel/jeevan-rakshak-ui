export type Severity = 'critical' | 'high' | 'moderate' | 'advisory'
export type Hazard = 'cyclone' | 'flood' | 'rain' | 'earthquake' | 'fire' | 'landslide'

export type Alert = {
  id: string
  severity: Severity
  hazard: Hazard
  title: string
  area: string
  issued: string
  distance: string
  status: 'New' | 'Escalating' | 'Stable'
  source: string
  instructions: string[]
}

export const alerts: Alert[] = [
  {
    id: 'a1',
    severity: 'critical',
    hazard: 'cyclone',
    title: 'Cyclone "Vayu" — landfall expected in 18 hours',
    area: 'Coastal Ratnagiri, Maharashtra',
    issued: '12:05 IST',
    distance: '142 km',
    status: 'Escalating',
    source: 'IMD',
    instructions: ['Move to higher ground', 'Keep phone and power bank charged', 'Stay away from the coastline'],
  },
  {
    id: 'a2',
    severity: 'high',
    hazard: 'flood',
    title: 'Flood warning on Mula-Mutha riverbanks',
    area: 'Kothrud & Shivajinagar, Pune',
    issued: '13:10 IST',
    distance: '6.4 km',
    status: 'New',
    source: 'IMD · PMC',
    instructions: ['Avoid low-lying roads', 'Move valuables to upper floors', 'Do not cross flowing water'],
  },
  {
    id: 'a3',
    severity: 'moderate',
    hazard: 'rain',
    title: 'Heavy rainfall — orange alert',
    area: 'Pune district',
    issued: '09:40 IST',
    distance: 'Your area',
    status: 'Stable',
    source: 'IMD',
    instructions: ['Limit non-essential travel', 'Clear drains near your home', 'Keep an emergency kit ready'],
  },
  {
    id: 'a4',
    severity: 'moderate',
    hazard: 'landslide',
    title: 'Landslide risk on ghat sections',
    area: 'Lonavala – Khandala',
    issued: '08:15 IST',
    distance: '58 km',
    status: 'Stable',
    source: 'GSI · SDMA',
    instructions: ['Avoid ghat roads after dark', 'Watch for falling debris', 'Follow traffic police advisories'],
  },
  {
    id: 'a5',
    severity: 'advisory',
    hazard: 'earthquake',
    title: 'Minor tremor (M3.1) recorded',
    area: 'Koyna region, Satara',
    issued: '06:52 IST',
    distance: '96 km',
    status: 'Stable',
    source: 'NCS',
    instructions: ['No action needed', 'Review drop-cover-hold drill', 'Report any structural cracks'],
  },
  {
    id: 'a6',
    severity: 'advisory',
    hazard: 'fire',
    title: 'Forest fire contained',
    area: 'Sinhagad foothills',
    issued: 'Yesterday',
    distance: '21 km',
    status: 'Stable',
    source: 'Forest Dept.',
    instructions: ['Avoid trekking routes', 'Report smoke sightings', 'Keep windows closed if smoky'],
  },
]

export type PlaceType = 'shelter' | 'hospital' | 'relief' | 'emergency'

export type Place = {
  id: string
  name: string
  type: PlaceType
  distance: string
  eta: string
  status: 'Open' | 'Near capacity' | 'Full'
  facilities: string[]
  capacity?: { used: number; total: number }
  verified: string
  position: [number, number]
}

export const userPosition: [number, number] = [18.5074, 73.8077]

export const places: Place[] = [
  {
    id: 'p1',
    name: 'Kothrud Community Relief Centre',
    type: 'relief',
    distance: '1.2 km',
    eta: '4 min drive',
    status: 'Open',
    facilities: ['Shelter', 'Food', 'Medical', 'Water'],
    capacity: { used: 142, total: 200 },
    verified: '20 min ago',
    position: [18.5132, 73.8165],
  },
  {
    id: 'p2',
    name: 'MIT School Shelter Hall',
    type: 'shelter',
    distance: '2.1 km',
    eta: '7 min drive',
    status: 'Open',
    facilities: ['Shelter', 'Water', 'Power'],
    capacity: { used: 64, total: 300 },
    verified: '35 min ago',
    position: [18.5182, 73.8152],
  },
  {
    id: 'p3',
    name: 'Sahyadri Super Speciality Hospital',
    type: 'hospital',
    distance: '2.8 km',
    eta: '9 min drive',
    status: 'Open',
    facilities: ['ICU', 'Trauma', 'Blood bank'],
    verified: '10 min ago',
    position: [18.4985, 73.8248],
  },
  {
    id: 'p4',
    name: 'Karve Nagar Municipal School',
    type: 'shelter',
    distance: '3.4 km',
    eta: '11 min drive',
    status: 'Near capacity',
    facilities: ['Shelter', 'Food'],
    capacity: { used: 182, total: 200 },
    verified: '1 hr ago',
    position: [18.4893, 73.8156],
  },
  {
    id: 'p5',
    name: 'Fire & Rescue Station, Erandwane',
    type: 'emergency',
    distance: '3.9 km',
    eta: '12 min drive',
    status: 'Open',
    facilities: ['Rescue boats', 'Ambulance'],
    verified: '5 min ago',
    position: [18.5101, 73.8315],
  },
  {
    id: 'p6',
    name: 'Deenanath Mangeshkar Hospital',
    type: 'hospital',
    distance: '4.2 km',
    eta: '13 min drive',
    status: 'Open',
    facilities: ['Emergency', 'ICU'],
    verified: '15 min ago',
    position: [18.5022, 73.8331],
  },
]

export const dangerZones: [number, number][][] = [
  [
    [18.5245, 73.8302],
    [18.5276, 73.8418],
    [18.5205, 73.8475],
    [18.5162, 73.8389],
    [18.5188, 73.8312],
  ],
]

export const safeZones: { center: [number, number]; radius: number }[] = [
  { center: [18.5132, 73.8165], radius: 380 },
  { center: [18.5182, 73.8152], radius: 280 },
]

export type HelpRequest = {
  id: string
  type: 'Food' | 'Medical' | 'Shelter' | 'Rescue' | 'Water'
  title: string
  people: number
  area: string
  distance: string
  posted: string
  urgency: 'Critical' | 'High' | 'Medium' | 'Low'
  vulnerable?: string
}

export const helpRequests: HelpRequest[] = [
  {
    id: 'r1',
    type: 'Rescue',
    title: 'Elderly couple stranded on ground floor',
    people: 2,
    area: 'Shivajinagar',
    distance: '5.1 km',
    posted: '8 min ago',
    urgency: 'Critical',
    vulnerable: 'Elderly',
  },
  {
    id: 'r2',
    type: 'Medical',
    title: 'Insulin needed for diabetic patient',
    people: 1,
    area: 'Kothrud',
    distance: '1.6 km',
    posted: '15 min ago',
    urgency: 'High',
  },
  {
    id: 'r3',
    type: 'Food',
    title: 'Dry rations for family of six',
    people: 6,
    area: 'Warje',
    distance: '3.2 km',
    posted: '32 min ago',
    urgency: 'Medium',
    vulnerable: 'Children',
  },
  {
    id: 'r4',
    type: 'Shelter',
    title: 'Temporary stay for 3 nights',
    people: 4,
    area: 'Karve Nagar',
    distance: '2.9 km',
    posted: '1 hr ago',
    urgency: 'Medium',
  },
  {
    id: 'r5',
    type: 'Water',
    title: 'Drinking water for apartment block',
    people: 40,
    area: 'Erandwane',
    distance: '3.7 km',
    posted: '2 hr ago',
    urgency: 'Low',
  },
]

export type Ngo = {
  id: string
  name: string
  focus: string
  region: string
  raised: number
  goal: number
  donors: number
  verified: boolean
}

export const ngos: Ngo[] = [
  {
    id: 'n1',
    name: 'Seva Relief Foundation',
    focus: 'Flood rescue & emergency kits',
    region: 'Pune · Satara',
    raised: 1840000,
    goal: 2500000,
    donors: 3214,
    verified: true,
  },
  {
    id: 'n2',
    name: 'Sahyadri Disaster Response',
    focus: 'Community shelters & meals',
    region: 'Western Ghats',
    raised: 920000,
    goal: 1500000,
    donors: 1488,
    verified: true,
  },
  {
    id: 'n3',
    name: 'Coastal Lifeline Trust',
    focus: 'Cyclone preparedness',
    region: 'Konkan coast',
    raised: 640000,
    goal: 2000000,
    donors: 902,
    verified: true,
  },
]

export const inr = (n: number) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n)
